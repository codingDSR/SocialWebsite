<?php
include_once("php_includes/check_login_status.php");
// If user is already logged in, header that weenis away
if($user_ok == true){
    header("location: feeds.php");
	//header("location: user.php?u=".$_SESSION["username"]);
    exit();
}
?><?php
// AJAX CALLS THIS LOGIN CODE TO EXECUTE
if(isset($_POST["e"])){
	// CONNECT TO THE DATABASE
	include_once("php_includes/db_conx.php");
	// GATHER THE POSTED DATA INTO LOCAL VARIABLES AND SANITIZE
	$e = mysqli_real_escape_string($db_conx, $_POST['e']);
	$p = sha1(mysqli_real_escape_string($db_conx, $_POST['p']));
	//$p = sha1($_POST['p']);
	// GET USER IP ADDRESS
    $ip = preg_replace('#[^0-9.]#', '', getenv('REMOTE_ADDR'));
	// FORM DATA ERROR HANDLING
	if($e == "" || $p == ""){
		echo "login_failed";
        exit();
	} else {
	// END FORM DATA ERROR HANDLING
		$sql = "SELECT id, username, password FROM users WHERE email='$e' OR username='$e' AND activated='1' LIMIT 1";
        $query = mysqli_query($db_conx, $sql);
        $row = mysqli_fetch_row($query);
		$db_id = $row[0];
		$db_username = $row[1];
        $db_pass_str = $row[2];
		if($p != $db_pass_str){
			echo "login_failed";
            exit();
		} else {
			// CREATE THEIR SESSIONS AND COOKIES
			$_SESSION['userid'] = $db_id;
			$_SESSION['username'] = $db_username;
			$_SESSION['password'] = $db_pass_str;
			setcookie("id", $db_id, strtotime( '+30 days' ), "/", "", "", TRUE);
			setcookie("user", $db_username, strtotime( '+30 days' ), "/", "", "", TRUE);
    		//setcookie("pass", $db_pass_str, strtotime( '+30 days' ), "/", "", "", TRUE);
			// UPDATE THEIR "IP" AND "LASTLOGIN" FIELDS
			$sql = "UPDATE users SET ip='$ip', lastlogin=now() WHERE username='$db_username' LIMIT 1";
            $query = mysqli_query($db_conx, $sql);
			echo $db_username;
		    exit();
		}
	}
	exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta name="description" content="">
    <meta name="author" content="">
	<style>
		@import url('https://fonts.googleapis.com/css?family=Dosis:400,600|Open+Sans:300,400,600|Roboto:300,400,500');
	</style>
	<link rel="icon" href="favicon.ico" type="image/x-icon">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="js/main.js"></script>
	<script src="js/ajax.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<title>Log In</title>
<link rel="stylesheet" href="style/style.css"/>
<style type="text/css">
body {font-size:15px}
.container {margin-top:125px;}
#loginform .form-control { margin-top:13px;margin-bottom:15px; }
#loginform button { background:#00acee;padding:8px;font-size:18px; }
#loginform input {height: 38px;padding: 12px;background: transparent; }
::-webkit-input-placeholder { /* Chrome/Opera/Safari */
  font-weight:600;
  color:rgb(120,120,120);
}
::-moz-placeholder { /* Firefox 19+ */
  font-weight:600;
  color:rgb(120,120,120);
}
:-ms-input-placeholder { /* IE 10+ */
  font-weight:600;
  color:rgb(120,120,120);
}
:-moz-placeholder { /* Firefox 18- */
  font-weight:600;
  color:rgb(120,120,120);
}
.container .row h3 {margin-bottom:35px;}
@media only screen and (max-width: 500px) {
.container .row h3 {font-size:20px;}
.container {margin-top:80px;}
}
</style>
<script src="js/main.js"></script>
<script src="js/ajax.js"></script>
<script>
function emptyElement(x){
	_(x).innerHTML = "";
}
function login(){
	var e = _("email").value;
	var p = _("password").value;
	if(e == "" || p == ""){
		_("status").innerHTML = "Fill out all of the form data";
	} else {
		_("loginbtn").style.display = "none";
		_("status").innerHTML = 'please wait ...';
		var ajax = ajaxObj("POST", "login.php");
        ajax.onreadystatechange = function() {
	        if(ajaxReturn(ajax) == true) {
	            if(ajax.responseText == "login_failed"){
					_("status").innerHTML = "Login failed, please enter correct credentials.";
					_("loginbtn").style.display = "block";
				} else {
					window.location = "feeds.php";
				}
	        }
        }
        ajax.send("e="+e+"&p="+p);
	}
}
</script>
</head>
<body>
<?php //include_once("template_pageTop.php"); ?>
<nav class="navbar navbar-inverse navbar-fixed-top no-margin">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>
      <a class="navbar-brand" href="#">Codingflag</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="signup.php">Sign Up</a></li>
      </ul>
    </div>
  </div>
</nav>
<!--
<div class="container">
	<div class="login-container">
            <div id="output"></div>
			<div style="margin-top: 5px;font-size: 18px;margin-bottom: 25px;color: #564a4a;font-weight: 600;">Log In to your account</div>
            <div class="avatar"><img src="images/avatardefault.png" style="border-radius:50%;" width="100%" height="100%"></div>
            <div class="form-box">
                <form id="loginform" onsubmit="return false;">
                    <input type="email" id="email" onfocus="emptyElement('status')" maxlength="88" placeholder="Email ID"/>
                    <input placeholder="Password" type="password" id="password" onfocus="emptyElement('status')" maxlength="20"/>
                    <button  type="button" id="loginbtn" onclick="login()" class="btn btn-info btn-block login">Login</button>
                </form>
                <p id="status"></p>
            </div>
            <div style="margin-top:15px;" class="text-center">
            	<a href="signup.php">Not a member? Sign up now</a>
            </div>
    </div>
</div>
-->
	<div class="container">
		<div class="row">
			<div class="col-xs-12 col-sm-12 col-md-3"></div>
			<div class="col-xs-12 col-sm-12 col-md-6">
				<h3>Log in to Codingflag.<h3>
            <div class="form-box">
                <form id="loginform" onsubmit="return false;">
                    <input class="form-control" type="email" id="email" onfocus="emptyElement('status')" maxlength="88" placeholder="Email ID / Username"/>
                    <input class="form-control" placeholder="Password" type="password" id="password" onfocus="emptyElement('status')" maxlength="20"/>
                    <button  type="button" id="loginbtn" onclick="login()" class="btn btn-info btn-block login">Login</button>
                </form>
                <p style="font-size:15px;margin-top:20px;text-align:center;" id="status"></p>
            </div>
            <div style="margin-top:20px;" class="">
            	<a style="font-size:16px;" href="signup.php">Not a member? Sign up now</a>
            </div>				
			</div>
			<div class="col-xs-12 col-sm-12 col-md-3"></div>
		</div>
	</div>

</body>
</html>

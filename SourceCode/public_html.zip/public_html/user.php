<?php
include_once("php_includes/check_login_status.php");

// Initialize any variables that the page might echo
$u = "";
$sex = "Male";
$userlevel = "";
$profile_pic = "";
$profile_pic_btn = "";
$avatar_form = "";
$avatar_form_2nd = '';
$country = "";
$joindate = "";
$lastsession = "";

// Make sure the _GET username is set, and sanitize it
if(isset($_GET["u"])){
	$u = preg_replace('#[^a-z0-9]#i', '', $_GET['u']);
	require_once('php_includes/dir_hash.php');
	//require_once('php_includes/libs_link.php');
	require_once('php_includes/process_post_data.php');
	require_once('view_components/template_logged_user_avatar.php');
} else {
    //page not exist page..
    header("location: login.php");
    exit();
}

function get_domain($url) {
  $pieces = parse_url($url);
  $domain = isset($pieces['host']) ? $pieces['host'] : '';
  if (preg_match('/(?P<domain>[a-z0-9][a-z0-9\-]{1,63}\.[a-z\.]{2,6})$/i', $domain, $regs)) {
    return $regs['domain'];
  }
  return false;
}
$loguserID = $log_id;

// Select the member from the users table
$sql = "SELECT * FROM users WHERE username='$u' AND activated='1' LIMIT 1";
$user_query = mysqli_query($db_conx, $sql);
// Now make sure that user exists in the table
$numrows = mysqli_num_rows($user_query);
if($numrows < 1){
	require_once('view_components/template_not_found.php');
	//echo "That user does not exist or is not yet activated, press back";
    exit();
} 
// Check to see if the viewer is the account owner
$isOwner = "no";
if($u == $log_username && $user_ok == true){
	$isOwner = "yes";
	$profile_pic_btn = '<div class="user-profile-change-element"><div href="#" onclick="return false;" data-toggle="modal" data-target="#AvatarChange"> <i class="fa fa-picture-o" aria-hidden="true"></i> &nbsp;Change Avatar</div></div>';
	$avatar_form  = '<form id="avatar_form" enctype="multipart/form-data" method="post" action="php_parsers/photo_system.php">';
	// $avatar_form .=   '<h4>Change your avatar</h4>';
	// $avatar_form .=   '<input type="file" name="avatar" required>';
	// $avatar_form_2nd .=   '<p><input type="submit" value="Upload"></p>';
	// $avatar_form_2nd .= '</form>';
	$avatar_form  .= '<form id="avatar_form" enctype="multipart/form-data" method="post" action="php_parsers/photo_system.php">';
	$avatar_form  .= '<div class="avatarUpload">';
	$avatar_form  .= '<input accept="image/*" onchange="loadFile(event)" type="file" id="avatarchooser" name="avatar" required="">';
	$avatar_form  .= '<label for="avatarchooser">Click here to select image<label>';	
	$avatar_form  .= '</div>';
	$avatar_form  .= '<img id="output" style="margin-top:7px;">';
	$avatar_form_2nd  .= '</form>';
}
// Fetch the user row from the query above
while ($row = mysqli_fetch_array($user_query, MYSQLI_ASSOC)) {
	$profile_id = $row["id"];
	$gender = $row["gender"];
	$bioData = $row["bio_data"];
	$website = $row["website"];
	$city = $row["city"];
	//$country = $row["country"];
	$userlevel = $row["userlevel"];
	$avatar = $row["avatar"];
	$signup = $row["signup"];
	$lastlogin = $row["lastlogin"];
	$joindate = strftime("%b %d, %Y", strtotime($signup));
	$lastsession = strftime("%b %d, %Y", strtotime($lastlogin));
}
if($gender == "f"){
	$sex = "Female";
}
if($avatar == NULL){
	$get_profile_pic = '<img src="images/avatardefault.jpg" alt="'.$u.'">';
} else {
	$get_profile_pic = '<img src="user/'.dir_encrypt($u).'/'.$avatar.'" alt="'.$u.'">';
}
?>

<?php
$isFriend = false;
$cancelRequest = false;
$ownerBlockViewer = false;
$viewerBlockOwner = false;
if($u != $log_username && $user_ok == true){
	$friend_check = "SELECT id FROM friends WHERE user1_id='$log_id' AND user2_id='$profile_id' AND accepted='1' OR user1_id='$profile_id' AND user2_id='$log_id' AND accepted='1' LIMIT 1";
	if(mysqli_num_rows(mysqli_query($db_conx, $friend_check)) > 0){
        $isFriend = true;
    } else {
		$friend_check = "SELECT id FROM friends WHERE user1_id='$log_id' AND user2_id='$profile_id' AND accepted='0' LIMIT 1";
		if(mysqli_num_rows(mysqli_query($db_conx, $friend_check)) > 0){
	        $cancelRequest = true;
	    }    	
    }
	// $block_check1 = "SELECT id FROM blockedusers WHERE blocker='$u' AND blockee='$log_username' LIMIT 1";
	// if(mysqli_num_rows(mysqli_query($db_conx, $block_check1)) > 0){
 //        $ownerBlockViewer = true;
 //    }
	// $block_check2 = "SELECT id FROM blockedusers WHERE blocker='$log_username' AND blockee='$u' LIMIT 1";
	// if(mysqli_num_rows(mysqli_query($db_conx, $block_check2)) > 0){
 //        $viewerBlockOwner = true;
 //    }
}
?><?php
$friend_button = '';
//$friend_button = '<button disabled>Request As Friend</button>';
//$block_button = '<button disabled>Block User</button>';
// LOGIC FOR FRIEND BUTTON
if($isFriend == true){
	$friend_button = '<button onclick="friendToggle(\'unfriend\',\''.$profile_id.'\',\'friendBtn\')">Unfriend</button>';
} else if($cancelRequest == true){
	$friend_button = '<button onclick="friendToggle(\'cancelrequest\',\''.$profile_id.'\',\'friendBtn\')">Cancel Request</button>';
} else  if($user_ok == true && $u != $log_username && $ownerBlockViewer == false){
	$friend_button = '<button onclick="friendToggle(\'friend\',\''.$profile_id.'\',\'friendBtn\')">Request As Friend</button>';
}
// LOGIC FOR BLOCK BUTTON
// if($viewerBlockOwner == true){
// 	$block_button = '<button onclick="blockToggle(\'unblock\',\''.$u.'\',\'blockBtn\')">Unblock User</button>';
// } else if($user_ok == true && $u != $log_username){
// 	$block_button = '<button onclick="blockToggle(\'block\',\''.$u.'\',\'blockBtn\')">Block User</button>';
// }
?><?php
$friendsHTML = '';
$friends_view_all_link = '';
$sql = "SELECT COUNT(id) FROM friends WHERE user1_id='$profile_id' AND accepted='1' OR user2_id='$profile_id' AND accepted='1'";
$query = mysqli_query($db_conx, $sql);
$query_count = mysqli_fetch_row($query);
$friend_count = $query_count[0];
if($friend_count < 1){
	$friendsHTML = $u." has no friends yet";
} else {
	$max = 20;
	$all_friends = array();
	$sql = "SELECT user1_id FROM friends WHERE user2_id='$profile_id' AND accepted='1' LIMIT $max";
	$query = mysqli_query($db_conx, $sql);
	while ($row = mysqli_fetch_array($query, MYSQLI_ASSOC)) {
		array_push($all_friends, $row["user1_id"]);
	}
	$sql = "SELECT user2_id FROM friends WHERE user1_id='$profile_id' AND accepted='1' LIMIT $max";
	$query = mysqli_query($db_conx, $sql);
	while ($row = mysqli_fetch_array($query, MYSQLI_ASSOC)) {
		array_push($all_friends, $row["user2_id"]);
	}
	$friendArrayCount = count($all_friends);
	if($friendArrayCount > $max){
		array_splice($all_friends, $max);
	}
	if($friend_count > $max){
		//$friends_view_all_link = '<a href="view_friends.php?u='.$u.'">view all</a>';
	}
	$orLogic = '';
	foreach($all_friends as $key => $user){
			$orLogic .= "id='$user' OR ";
	}
	$orLogic = chop($orLogic, "OR ");
	$sql = "SELECT username, avatar FROM users WHERE $orLogic";
	$query = mysqli_query($db_conx, $sql);
	while($row = mysqli_fetch_array($query, MYSQLI_ASSOC)) {
		$friend_username = $row["username"];
		$friend_avatar = $row["avatar"];
		if($friend_avatar != ""){
			$friend_pic = 'user/'.dir_encrypt($friend_username).'/'.$friend_avatar.'';
		} else {
			$friend_pic = 'images/avatardefault.jpg';
		}
		$friendsHTML .='<div class="follower">';
        $friendsHTML .='<img class="friendpics" src="'.$friend_pic.'" alt="'.$friend_username.'" />';            
        $friendsHTML .='<div class="body">';
        $friendsHTML .='<div class="follower-controls">';
        $friendsHTML .='<a href="user.php?u='.$friend_username.'" class="btn btn-sm btn-outline">View Profile</a>';
        $friendsHTML .='</div>';
        $friendsHTML .='<a href="user.php?u='.$friend_username.'" class="follower-name">'.$friend_username.'</a><br>';
        $friendsHTML .='</div>';
        $friendsHTML .='</div>';
		//$friendsHTML .= '<a href="user.php?u='.$friend_username.'"><img class="friendpics" src="'.$friend_pic.'" alt="'.$friend_username.'" title="'.$friend_username.'"></a>';
	}
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta name="description" content="">
    <meta name="author" content="">
	<title><?php echo $u; ?></title>
	<style>
		@import url('https://fonts.googleapis.com/css?family=Dosis:400,600|Open+Sans:300,400,600|Roboto:300,400,500');
	</style>
	<link rel="icon" href="favicon.ico" type="image/x-icon">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="style/imageGallery.css"/>
	<style type="text/css">

		ul.gallery {
		  padding:0 0 0 0;
		  margin:0 0 40px 0;
		}
		ul.gallery li {
		  list-style:none;
		  margin-bottom:10px;
		}

		ul.gallery li .text {
		/*font-family: 'Bree Serif';*/
		color:#666;
		font-size:11px;
		margin-bottom:10px;
		padding:12px;
		background:#fff;
		}
	</style>
	<script src="js/main.js"></script>
	<script src="js/ajax.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
	<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
	<script src="js/imageGallery.js"></script>
	<?php require_once('php_includes/common_js.php'); ?>
	<script type="text/javascript">
function friendToggle(type,user,elem){
	var conf = confirm("Press OK to confirm the '"+type+"' action for user <?php echo $u; ?>.");
	if(conf != true){
		return false;
	}
	_(elem).innerHTML = 'please wait ...';
	var ajax = ajaxObj("POST", "php_parsers/friend_system.php");
	ajax.onreadystatechange = function() {
		if(ajaxReturn(ajax) == true) {
			if(ajax.responseText == "friend_request_sent"){
				_(elem).innerHTML = '<a style="text-decoration:none;position: relative;font-size:16px;top: 15px;padding: 6px 12px;text-align: center;width: 200px;background: #4d8ab5;color: #eee;">Friend Request Sent</a>';
			} else if(ajax.responseText == "unfriend_ok"){
				window.location.assign(window.location.href);
				_(elem).innerHTML = '<button onclick="friendToggle(\'friend\',\'<?php echo $u; ?>\',\'friendBtn\')">Request As Friend</button>';
			} else if(ajax.responseText == "cancel_ok") {
				_(elem).innerHTML = '<button onclick="friendToggle(\'friend\',\'<?php echo $u; ?>\',\'friendBtn\')">Request As Friend</button>';				
			} else {
				//alert();
				_(elem).innerHTML = '<p style="margin-top:10px;">'+ajax.responseText+'</p>';
			}
		}
	}
	ajax.send("type="+type+"&user="+<?php echo $profile_id;?>);
}
function blockToggle(type,blockee,elem){
	var conf = confirm("Press OK to confirm the '"+type+"' action on user <?php echo $u; ?>.");
	if(conf != true){
		return false;
	}
	var elem = document.getElementById(elem);
	elem.innerHTML = 'please wait ...';
	var ajax = ajaxObj("POST", "php_parsers/block_system.php");
	ajax.onreadystatechange = function() {
		if(ajaxReturn(ajax) == true) {
			if(ajax.responseText == "blocked_ok"){
				elem.innerHTML = '<button onclick="blockToggle(\'unblock\',\'<?php echo $u; ?>\',\'blockBtn\')">Unblock User</button>';
			} else if(ajax.responseText == "unblocked_ok"){
				elem.innerHTML = '<button onclick="blockToggle(\'block\',\'<?php echo $u; ?>\',\'blockBtn\')">Block User</button>';
			} else {
				alert(ajax.responseText);
				elem.innerHTML = 'Try again later';
			}
		}
	}
	ajax.send("type="+type+"&blockee="+blockee);
}
var loadFile = function(event) {
 	var output = document.getElementById('output');
	var file = event.target.files[0];
	if(file.name == ""){
		return false;		
	}
	if(file.type != "image/jpeg" && file.type != "image/png"){
		alert("This file type is not supported.");
		return false;
	}
	output.src = URL.createObjectURL(event.target.files[0]);
	output.style.width = "170px";
};
</script>
</head>
<body>
<?php if(!isset($_SESSION["username"])){
	echo '<div id="user_not_logged"><h4>See more by logging in to Codingflag</h4><div><a class="btn" href="signup.php">Signup</a><a class="btn" href="login.php">Login</a></div></div>';
}	
?>
<?php include_once("view_components/template_pageTop.php"); ?>
<?php include_once("view_components/template_status.php"); ?>
        <div id="page-content-wrapper">
        	<div style="margin-top:60px;"></div>	
            <div class="container-fluid xyz row">
				<h2 class="display-for-mob"><?php echo $u; ?></h2>
				<div class="col-xs-12 col-sm-12 col-md-3 profile-left">	
				  <div id="profile_pic_box" ><?php echo $get_profile_pic; ?><?php echo $profile_pic_btn; ?></div>
				  <div><span id="friendBtn"><?php echo $friend_button; ?></span></div>	
				  <!-- <p>Is the viewer the page owner, logged in and verified? <b><?php //echo $isOwner; ?></b></p> -->
				  <div class="about">
					  <p>About 
						<?php 
							if($u == $log_username && $user_ok == true) {
								$rdvar = time().rand(100,100000);
								echo " &nbsp;<a href=\"about_edit.php?dtd=$rdvar\" style=\"float: right;padding-right: 20px;\"><i class='fa fa-pencil'></i></a>";
							}
						?>
					  	<p><b>Points: </b> <?php echo (($total_status_nums*3)+($friend_count*2)+($total_photos*1)); ?></p>
						<?php	
							if(!empty($bioData)){
								echo '<p><b>Bio: </b> '.$bioData.'</p>';
							}								
							if(!empty($gender)){
								if($gender == 'm'){
									echo '<p><b>Gender: </b> Male</p>';
								} else if($gender == 'f'){
									echo '<p><b>Gender: </b> Female</p>';
								}
							}
							if(!empty($website)){
								echo '<p><b>Website:</b> <a href="'.$website.'" target="_blank">'. get_domain($website).'</a></p>';
							}							
							if(!empty($city)){
								echo '<p><b>City: </b> '.$city.'</p>';
							}														
						?>
					  </p>
					  <p><b>Join Date:</b> <?php echo $joindate; ?></p>
					  <p><b>Last Session:</b> <?php echo $lastsession; ?></p>
				  </div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-8 mainside">
					<div class="row">
					<div><h2 class="display-for-non-mob"><?php echo $u.'\'s profile'; ?></h2></div>
					<ul id="uidemo-tabs-default-demo" class="nav nav-tabs nav-tabs-simple profile-nav-tab">
						<li class="active">
							<a href="#profile-posts-tab" data-toggle="tab" aria-expanded="true">
								<i class="menu-icon fa fa-pencil"></i><span class="txt-note">&nbsp; Posts&nbsp;</span>
								<span class="text-light-gray"><?php echo $total_status_nums; ?></span>
							</a>
						</li>

						<li class="">
							<a href="#profile-images-tab" data-toggle="tab" aria-expanded="false">
								<i class="menu-icon fa fa-camera"></i><span class="txt-note">&nbsp;Pictures</span>
								<span class="text-light-gray"><?php echo $total_photos; ?></span>
							</a>
						</li>
						<li class="">
							<a href="#profile-friends-tab" data-toggle="tab" aria-expanded="false">
								<i class="menu-icon fa fa-users"></i><span class="txt-note">&nbsp;Friends</span>
								<span class="text-light-gray"><?php echo $friend_count; ?></span>
							</a>
						</li>
					</ul>
					<div class="tab-content-bordered tab-content">
						<div class="tab-pane fade active in" id="profile-posts-tab">
							<br>
							<div id="statusui">
							  <?php echo $status_ui; ?>
							</div>
							<div id="statusarea">
							  <?php echo $statuslist; ?>
							</div>	
						</div>
						<div class="tab-pane fade in" id="profile-images-tab">
							<div style="height:30px;"></div>
							<?php
								if($total_photos > 0){
									echo '<ul class="gallery">'.$photos_gallery.'</ul>';
								} else {
									echo "No photos";
								}
							?>
						</div>		
						<div class="tab-pane fade in" id="profile-friends-tab">
							<div style="height:10px;"></div>
							<?php echo $friendsHTML ?>
						</div>
					</div>	
					</div>			
				</div>
            </div>
        </div>
    </div>
<?php include_once("view_components/template_pageBottom.php"); ?>



<script src="js/sidebar_menu.js"></script>
<script type="text/javascript">
const totalStatus = <?php echo $total_status_nums; ?>;
var isLoadingNewStatusComments = false;
const loadMoreComments = function(e,ref,tym){
		if(checkNetConnectivity()){
			noConnectionStatusDisplay();
			return ;
		}		
		if(typeof tym == "number" && tym>0){
			ref = $(ref);
		} 
		e.preventDefault();
		if(isLoadingNewStatusComments == false){
			isLoadingNewStatusComments = true;
			ref.parent().html('<div class="loading-new-status" style="text-align:center;"><img src="images/loading-arrow.gif" style="width: 17px;height: 17px;"/> Loading...</div>');
			var totalComments = parseInt(ref.attr('data-trep'));
			var loadedComments = parseInt(ref.attr('data-loaded'));
			var statusid = parseInt(ref.attr('data-std'));

			if(isLoadingNewStatusComments){
					var ajax = ajaxObj("POST", "php_parsers/get_more_status_comments_system.php");
					ajax.onreadystatechange = function() {
						if(ajaxReturn(ajax) == true) {
							if(ajax.responseText.length > 50){
								isLoadingNewStatusComments = false;
								$('#commentbox_'+statusid+' .load-more-comments').html('').hide();
								ref.parent().html('').hide();
								_('commentbox_'+statusid).innerHTML += ajax.responseText; 
							}
						}
					}
					ajax.send("action=load_status_comments&u=<?php echo $u;?>&uid=<?php echo $user_id;?>&statusid="+statusid+"&loadedComments="+loadedComments);
			}
		} else {
			return ;
		}				
}
$(document).ready(function(){
	var availableStatus = 20;
	var isLoadingNewStatus = false;
	$('.sidebar-nav li').eq(1).addClass('active');
	$('ul.gallery').bsPhotoGallery({
      "classes" : "col-lg-3 col-md-4 col-sm-3 col-xs-4 col-xxs-12",
      "hasModal" : true,
      "fullHeight" : false
    });
    $('.load-more-comments a').click(function(e){
		loadMoreComments(e,$(this));
	});
    window.onscroll = function(){
    	if(isLoadingNewStatus == true){
    		return;
    	}
		if ($(window).scrollTop() >= ($(document).height() - $(window).height())*0.9){
			if(checkNetConnectivity()){
				noConnectionStatusDisplay();
				return ;
			}				
			isLoadingNewStatus = true;
			if(isLoadingNewStatus){
					_('statusarea').innerHTML += '<div class="loading-new-status" style="margin-top:20px;text-align:center;"><img src="images/loading-arrow.gif" style="width: 20px;height: 20px;"/> Loading...</div>';
					var ajax = ajaxObj("POST", "php_parsers/get_more_status_system.php");
					ajax.onreadystatechange = function() {
						if(ajaxReturn(ajax) == true) {
							if(ajax.responseText.length > 50){
								isLoadingNewStatus = false;
								availableStatus += 5;
								$('.loading-new-status').html('').hide();
								_('statusarea').innerHTML += ajax.responseText;								
								if(availableStatus >= totalStatus){
									window.onscroll = null;
									_('statusarea').innerHTML += "<div><br><center>End of posts</center></div>";
								}
							}
						}
					}
					ajax.send("action=load_status&nowOnPointer="+availableStatus+"&u=<?php echo $u;?>&uid=<?php echo $user_id;?>");
			}
		}
    };
    (function(){
    	if(totalStatus < 20){
    		window.onscroll = null;
    	} 
    	<?php if(!isset($_SESSION['username'])){echo 'window.onscroll=null;';}?>
    })();

});




</script>

<!-- Modals -->
<div class="modal fade in" id="AvatarChange" role="dialog" aria-hidden="false">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">×</button>
          <h4 class="modal-title">Change your Avatar <now!></now!></h4>
        </div>
        <div class="modal-body" style="text-align:center;">
          <?php echo $avatar_form; ?>
 	   </div>
        <div class="modal-footer">
          <input type="submit" class="btn btn-warning" value="Upload"> 
          <?php if($u == $log_username && $user_ok == true){echo $avatar_form_2nd;} ?>         
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> 
        </div>
      </div>
    </div>
</div>

</body>
</html>


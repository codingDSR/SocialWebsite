<?php
include_once("php_includes/check_login_status.php");
// If the page requestor is not logged in, usher them away
if($user_ok != true || $log_username == ""){
	header("location: login.php");
    exit();
} else {
	require_once('php_includes/dir_hash.php');
}
?>

<?php
$friend_requests = "";
$sql = "SELECT f.*,u.username as 'user1_name',u.avatar as 'user_avatar' FROM friends f,users u WHERE user2_id='$log_id' AND accepted='0' AND f.user1_id=u.id ORDER BY datemade DESC LIMIT 25";
$query = mysqli_query($db_conx, $sql);
$numrows = mysqli_num_rows($query);
if($numrows < 1){
	$friend_requests = ' &nbsp; No friend requests';
} else {
	while ($row = mysqli_fetch_array($query, MYSQLI_ASSOC)) {
		$reqID = $row["id"];
		$user1 = $row["user1_id"];
		$user1_name = $row["user1_name"];
		$datemade = $row["datemade"];
		$datemade = strftime("%B %d", strtotime($datemade));
		//$thumbquery = mysqli_query($db_conx, "SELECT avatar FROM users WHERE id='$user1' LIMIT 1");
		//$thumbrow = mysqli_fetch_row($thumbquery);
		$user1avatar = $row["user_avatar"];		
		if($user1avatar == NULL){
			$user1pic = '<img src="images/avatardefault.jpg" alt="'.$user1.'" class="user_pic">';
		} else {
			$user1pic = '<img src="user/'.dir_encrypt($user1_name).'/'.$user1avatar.'" alt="'.$user1.'" class="user_pic">';
		}
		$friend_requests .= '<div id="friendreq_'.$reqID.'" class="friendrequests">';
		$friend_requests .= '<a href="user.php?u='.$user1_name.'">'.$user1pic.'</a>';
		$friend_requests .= '<div class="user_info" id="user_info_'.$reqID.'"><a href="user.php?u='.$user1_name.'">'.$user1_name.'</a><br /><span class="date">'.$datemade.'</span><br>';
		$friend_requests .= '<button class="accept" onclick="friendReqHandler(\'accept\',\''.$reqID.'\',\''.$user1.'\',\'user_info_'.$reqID.'\')">accept</button>  ';
		$friend_requests .= '<button class="reject" onclick="friendReqHandler(\'reject\',\''.$reqID.'\',\''.$user1.'\',\'user_info_'.$reqID.'\')">reject</button>';
		$friend_requests .= '</div>';
		$friend_requests .= '</div>';
	}
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta name="description" content="">
    <meta name="author" content="">
	<style>
		@import url('https://fonts.googleapis.com/css?family=Dosis:400,600|Open+Sans:300,400,600|Roboto:300,400,500');
	</style>
	<link rel="icon" href="favicon.ico" type="image/x-icon">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="style/style.css">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
	<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
	<script src="js/main.js"></script>
	<script src="js/ajax.js"></script>	
	<title>Friend Requests</title>
<style type="text/css">
/*div#notesBox{float:left; width:430px; border:#F0F 1px dashed; margin-right:60px; padding:10px;}
div#friendReqBox{float:left; width:430px; border:#F0F 1px dashed; padding:10px;}
div.friendrequests{height:74px; border-bottom:#CCC 1px solid; margin-bottom:8px;}
img.user_pic{float:left; width:68px; height:68px; margin-right:8px;}
div.user_info{float:left; font-size:14px;}*/
#friendReqBox div.friendrequests {
    min-height: 85px;
    padding: 4px;
    border-bottom: 1px solid rgba(34, 34, 34, 0.15);
}
#friendReqBox div.friendrequests img{
    width: 70px;
    height: 70px;
    float: left;
}
#friendReqBox div.friendrequests div.user_info {
    padding-left: 83px;	
}
#friendReqBox div.friendrequests span.date {
	font-size: 13px;
	color: rgb(100,100,100);
}
#friendReqBox div.friendrequests div.user_info button {
	border: none;
    outline: none;
    color: #eee;
    padding: 5px 10px;
    border-radius: 4px;	
}
#friendReqBox div.friendrequests div.user_info button.accept {
	background: #55acee;
}
#friendReqBox div.friendrequests div.user_info button.reject {
	background: #aaa;
}
    
</style>
<script type="text/javascript">
function friendReqHandler(action,reqid,user1,elem){
	// var conf = confirm("Press OK to '"+action+"' this friend request.");
	// if(conf != true){
	// 	return false;
	// }
	_(elem).innerHTML = "processing ...";
	var ajax = ajaxObj("POST", "php_parsers/friend_system.php");
	ajax.onreadystatechange = function() {
		if(ajaxReturn(ajax) == true) {
			if(ajax.responseText == "accept_ok"){
				_(elem).innerHTML = "<b>Request Accepted!</b><br />Your are now friends";
			} else if(ajax.responseText == "reject_ok"){
				_(elem).innerHTML = "<b>Request Rejected</b><br />You chose to reject friendship with this user";
			} else {
				_(elem).innerHTML = ajax.responseText;
			}
		}
	}
	ajax.send("action="+action+"&reqid="+reqid+"&user1="+user1);
}
</script>
</head>
<body>
	<?php include_once("view_components/template_pageTop.php"); ?>
        <div id="page-content-wrapper">
        	<div class="page--header">
        		<hr>
        		<h3>Friend Requests</h3>
        		<hr>
        	</div>			
            <div class="container-fluid xyz row">
            	<div class="row">
					<div class="col-xs-12 col-sm-12 col-md-8" id="profile-posts-tab">
						<div id="friendReqBox">
						  <?php echo $friend_requests; ?>
						</div>	
					</div>            		
					<div class="col-xs-12 col-sm-12 col-md-4"></div>
            	</div>
            </div>
        </div>
    </div>
	<?php include_once("view_components/template_pageBottom.php"); ?>






<div id="pageMiddle">
  <!-- START Page Content -->
  <!-- <div id="notesBox"><h2>Notifications</h2><?php //echo $notification_list; ?></div> -->
<!--   <div id="friendReqBox"><h2>Friend Requests</h2><?php //echo $friend_requests; ?></div> -->
  <div style="clear:left;"></div>
  <!-- END Page Content -->
</div>
	<?php include_once("view_components/template_pageBottom.php"); ?>
	<script src="js/sidebar_menu.js"></script>
	<script type="text/javascript">
$(document).ready(function(){
	$('.sidebar-nav li').eq(4).addClass('active');
});
	</script>
</body>
</html>

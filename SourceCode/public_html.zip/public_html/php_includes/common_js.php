<script type="text/javascript" page="comjs">
const checkNetConnectivity =function(){
	if(typeof navigator.onLine != undefined && typeof navigator.onLine == "boolean"){
		return !(navigator.onLine);
	} else {
		return false;
	}
}	
const ValidateEmail = function (mail) {
  return !(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail));
}
const trim = function(txt) {
	return txt.replace(/^\s+|\s+$/g,"");
}
const noConnectionStatusDisplay = function(){
	_('Notice-NoInternet').click();
	return ;	
}
const unexptedErrorMessage = function(){
	alert('unexpected error occurred. Refreshing page...');
	setTimeout(function(){
		window.location.assign(window.location.href);
	},2500);
};
function statusMax(field, maxlimit) {
	if (field.value.length > maxlimit){
		alert(maxlimit+" maximum character limit reached");
		field.value = field.value.substring(0, maxlimit);
	}
}
function triggerUpload(e,elem){
	e.preventDefault();
	_(elem).click();	
}

var hasImage = "";
window.onbeforeunload = function(){
	if(hasImage != ""){
	    return "You have not posted your image";
	}
}

function doUpload(id){
	if(checkNetConnectivity()){
		noConnectionStatusDisplay();
		return ;
	}
	var file = _(id).files[0];
	if(file.name == ""){
		return false;		
	}
	if(file.type != "image/jpeg" && file.type != "image/png" && file.type != "image/gif"){
		alert("This file type is not supported.");
		return false;
	}
	_("triggerBtn_SP").style.display = "none";
	_("uploadDisplay_SP").innerHTML = "<img src='images\\uploading.gif' width='90px'/>";
	var formdata = new FormData();
	formdata.append("stPic", file);
	var ajax = new XMLHttpRequest();
	ajax.addEventListener("load", completeHandler, false);
	ajax.addEventListener("error", errorHandler, false);
	ajax.addEventListener("abort", abortHandler, false);
	ajax.open("POST", "php_parsers/photo_system.php");
	ajax.send(formdata);	
}
function completeHandler(event){
	var data = event.target.responseText;
	var datArray = data.split("|");
	console.log(datArray);
	if(datArray[0].trim() == "upload_complete"){
		hasImage = datArray[1];
		_("uploadDisplay_SP").innerHTML = '<img src="tempUploads/'+datArray[1]+'" class="statusImage" />';
		_("triggerBtn_SP").style.display = "inline";
	} else {
		_("uploadDisplay_SP").innerHTML = datArray[0];
		_("triggerBtn_SP").style.display = "inline";
	}
}
function errorHandler(event){
	_("uploadDisplay_SP").innerHTML = "Upload Failed";
	_("triggerBtn_SP").style.display = "inline";
}
function abortHandler(event){
	_("uploadDisplay_SP").innerHTML = "Upload Aborted";
	_("triggerBtn_SP").style.display = "inline";
}
function postToStatus(action,type,user,ta){
	if(checkNetConnectivity()){
		noConnectionStatusDisplay();
		return ;
	}	
	var data = trim(_(ta).value);
	if(data == "" && hasImage == ""){
		//alert("Type something first weenis");
		return false;
	}
	var data2 = "";
	if(data != ""){
		data2 = data.replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/\n/g,"<br />").replace(/\r/g,"<br />");
	}
	if (data2 == "" && hasImage != ""){
		data = "||na||";
		data2 = '<img src="permUploads/'+hasImage+'" />';		
	} else if (data2 != "" && hasImage != ""){
		data2 += '<br /><img src="permUploads/'+hasImage+'" />';
	} else {
		hasImage = "na";
	}
	if(_('public_private_post').checked === true){
		type = 'd';
	} else {
		type = 'a';
	}
	
	_("statusBtn").disabled = true;
	var ajax = ajaxObj("POST", "php_parsers/status_system.php");
	ajax.onreadystatechange = function() {
		if(ajaxReturn(ajax) == true) {
			var datArray = ajax.responseText.split("|");
			if(datArray[0] == "post_ok"){
				var sid = datArray[1];
				var currentHTML = _("statusarea").innerHTML;
//				_("statusarea").innerHTML = '<div id="status_'+sid+'" class="status_boxes"><div><b>Posted by you just now:</b> <span id="sdb_'+sid+'"><a href="#" onclick="return false;" onmousedown="deleteStatus(\''+sid+'\',\'status_'+sid+'\');" title="DELETE THIS STATUS AND ITS REPLIES">delete status</a></span><br />'+data+'</div></div><textarea id="replytext_'+sid+'" class="replytext" onkeyup="statusMax(this,250)" placeholder="write a comment here"></textarea><button id="replyBtn_'+sid+'" onclick="replyToStatus('+sid+',\'<?php echo $u; ?>\',\'replytext_'+sid+'\',this)">Reply</button>'+currentHTML;
				_("statusarea").innerHTML = '<div id="status_'+sid+'" class="status_boxes"><div><b>Posted by you just now:</b> <span id="sdb_'+sid+'"><a href="#" onclick="return false;" onmousedown="deleteStatus(\''+sid+'\',\'status_'+sid+'\');" title="DELETE THIS STATUS AND ITS REPLIES">delete status</a></span><br />'+data2+'</div></div>'+currentHTML;
				_("statusBtn").disabled = false;
				_(ta).value = "";
				_("triggerBtn_SP").style.display = "inline";
				_("btns_SP").style.display = "inline";
				_("uploadDisplay_SP").innerHTML = "";
				_("fu_SP").value = "";
				hasImage = "";
			} else {
				//console.log(ajax.responseText);
				unexptedErrorMessage();
			}
		}
	}
	ajax.send("action="+action+"&type="+type+"&user="+<?php echo $log_id;?>+"&data="+data+"&image="+hasImage);
}
const hasClass = function( elem, cls ) {
     return (" " + elem.className + " " ).indexOf( " "+cls+" " ) > -1;
}
const likeOrUnlikeStatus = function(std,ref){
	if(checkNetConnectivity()){
		noConnectionStatusDisplay();
		return ;
	}	
	//ref.disabled = true;
	var action = "";
	ref.style.background = "#00acee";
	ref.innerHTML = "<img src=\"images/loader_basic.gif\" width=\"22px\" height=\"22px\">";
	if(parseInt(ref.getAttribute('data-std')) == parseInt(std)){
		std = parseInt(std);
	} else {
		alert('We are confused.Refreshing page ...');
	}
	if(ref.getAttribute('data-lkd') == '_y_' && hasClass(ref,'liked')) {
		action = "unlike_status";
	} else if(ref.getAttribute('data-lkd') == '_n_'){
		action = "like_status";
	} else {
		return ;
	}
	var ajax = ajaxObj("POST", "php_parsers/likes_system.php");
	ajax.onreadystatechange = function() {
		if(ajaxReturn(ajax) == true) {
			var likesData = JSON.parse(ajax.responseText);
			console.log(likesData);
			console.log(ajax.responseText);
			if(likesData.status == 'ok'){
				_('likes_'+std).innerHTML = likesData.total_likes+" likes";
				ref.innerHTML = '+1';
				ref.disabled = false;
				if(action =='like_status'){
					ref.classList.add('liked');
					ref.setAttribute('data-lkd','_y_');
				} else {
					ref.style.background = "transparent";
					ref.classList.remove('liked');
					ref.setAttribute('data-lkd','_n_');
				} 
				var likers_html = '';
				if(parseInt(likesData.total_likes) < 1){
					_('likers_tray_'+std).innerHTML = '';
					return ;
				}
				if(likesData.total_likes > 5){
					likers_html += '<a class="moreLikers">+'+(parseInt(likesData.total_likes)-5)+'</a>';
				} 
				for(var i=0;i<likesData.likers_avatar[0].length;i++){
					likers_html += '<img src="'+likesData.likers_avatar[0][i]+'"/>';
				}
				_('likers_tray_'+std).innerHTML = likers_html;

				//_(statusbox).style.display = 'none';
				//_("replytext_"+statusid).style.display = 'none';
				//_("replyBtn_"+statusid).style.display = 'none';
			} else {
				unexptedErrorMessage();
				//alert(likesData.error);
			}
		}
	}
	ajax.send("action="+action+"&statusid="+std);
}
function reportStatus(std){
	if(checkNetConnectivity()){
		noConnectionStatusDisplay();
		return ;
	}	
	std = parseInt(std);
	if(typeof std != "number") {
		return;
	}
	var ajax = ajaxObj("POST", "php_parsers/report_system.php");
	ajax.onreadystatechange = function() {
		if(ajaxReturn(ajax) == true) {
			if(ajax.responseText == "reported"){
				setTimeout(function(){
					_("status_"+std).style.display = "none";
					_("status_"+std).innerHTML = "";	
				},5000);
				_("status_"+std).style.padding = "6px";
				_("status_"+std).style.background = "#fbfbfb";
				_("status_"+std).style.border = "1px solid #ddd";
				_("status_"+std).innerHTML = '<center><h3>Reported!</h3><p>We will validate post soon.<div style="height:5px;"></div></p></center>';
			} else {
				unexptedErrorMessage();
				//alert(ajax.responseText);
			}
		}
	}
	ajax.send("action=report_status&statusid="+std);
}

function deleteStatus(statusid,statusbox){
	if(checkNetConnectivity()){
		noConnectionStatusDisplay();
		return ;
	}	
	var conf = confirm("Press OK to confirm deletion of this status and its replies");
	if(conf != true){
		return false;
	}
	var ajax = ajaxObj("POST", "php_parsers/status_system.php");
	ajax.onreadystatechange = function() {
		if(ajaxReturn(ajax) == true) {
			if(ajax.responseText == "delete_ok"){
				_(statusbox).style.display = 'none';
				_("replytext_"+statusid).style.display = 'none';
				_("replyBtn_"+statusid).style.display = 'none';
			} else {
				unexptedErrorMessage();
				//alert(ajax.responseText);
			}
		}
	}
	ajax.send("action=delete_status&statusid="+statusid);
}
function replyToStatus(sid,user,ta,btn){
	if(checkNetConnectivity()){
		noConnectionStatusDisplay();
		return ;
	}		
	var data = trim(_(ta).value);
	if(data == ""){
		//alert("Type something first weenis");
		return false;
	}
	_("replyBtn_"+sid).disabled = true;
	var ajax = ajaxObj("POST", "php_parsers/status_system.php");
	ajax.onreadystatechange = function() {
		if(ajaxReturn(ajax) == true) {
			var datArray = ajax.responseText.split("|");
			if(datArray[0] == "reply_ok"){
				var rid = datArray[1];
				data = data.replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/\n/g,"<br />").replace(/\r/g,"<br />");
				_("commentbox_"+sid).innerHTML += '<div id="reply_'+rid+'" class="reply_boxes row"><div><b>Reply by you just now: </b><span id="srdb_'+rid+'"><a href="#" onclick="return false;" onmousedown="deleteReply(\''+rid+'\',\'reply_'+rid+'\');" title="DELETE THIS COMMENT">Delete</a></span><br />'+data+'</div></div>';
				_("replyBtn_"+sid).disabled = false;
				_(ta).value = "";
			} else {
				unexptedErrorMessage();
				//alert(ajax.responseText);
			}
		}
	}
	ajax.send("action=status_reply&sid="+sid+"&user="+user+"&data="+data);
}
function deleteReply(replyid,replybox){
	if(checkNetConnectivity()){
		noConnectionStatusDisplay();
		return ;
	}		
	var conf = confirm("Press OK to confirm deletion of this reply");
	if(conf != true){
		return false;
	}
	var ajax = ajaxObj("POST", "php_parsers/status_system.php");
	ajax.onreadystatechange = function() {
		if(ajaxReturn(ajax) == true) {
			if(ajax.responseText == "delete_ok"){
				_(replybox).style.display = 'none';
				_(replybox).innerHTML = '';
			} else {
				unexptedErrorMessage();
				//alert(ajax.responseText);
			}
		}
	}
	ajax.send("action=delete_reply&replyid="+replyid);
}
</script>
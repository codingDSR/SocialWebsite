<?php 
function convertYoutube($string) {
    return preg_replace(
        "/\s*[a-zA-Z\/\/:\.]*youtu(be.com\/watch\?v=|.be\/)([a-zA-Z0-9\-_]+)([a-zA-Z0-9\/\*\-\_\?\&\;\%\=\.]*)/i",
        "<iframe class=\"youtubevideo\"src=\"//www.youtube.com/embed/$2\" allowfullscreen></iframe>",
        $string,
        1
    );
}
function convertCodepen($string) {
    return preg_replace(
        "/\s*[a-zA-Z\/\/:\.]*codepen(.io\/([a-zA-Z0-9\-_]+)\/pen\/)([a-zA-Z0-9\-_]+)/i",
        "<iframe height='346' scrolling='no' frameborder='no' allowtransparency='true' allowfullscreen='true' style='width: 100%;' class=\"codepen\"src=\"//codepen.io/$2/embed/preview/$3/?height=346&theme-id=dark&default-tab=result,css&embed-version=2\" allowfullscreen></iframe>",
        $string,
        1
    );
}
function makeClickableLinks($string) {
    $text = convertCodepen($string);
    //$string = str_replace('\t', "     ", $string);
    $text= preg_replace("/(^|[\n ])([\w]*?)([\w]*?:\/\/[\w]+[^ \,\"\n\r\t<]*)/is", "$1$2<a target=\"_blank\" href=\"$3\" >$3</a>", $text);  
    $text= preg_replace("/(^|[\n ])([\w]*?)((www)\.[^ \,\"\t\n\r<]*)/is", "$1$2<a target=\"_blank\" href=\"http://$3\" >$3</a>", $text);
    $text= preg_replace("/(^|[\n ])([\w]*?)((ftp)\.[^ \,\"\t\n\r<]*)/is", "$1$2<a target=\"_blank\" href=\"ftp://$3\" >$3</a>", $text);  
    $text= preg_replace("/(^|[\n ])([a-z0-9&\-_\.]+?)@([\w\-]+\.([\w\-\.]+)+)/i", "$1<a target=\"_blank\" href=\"mailto:$2@$3\">$2@$3</a>", $text);  
    //$string = preg_replace('/[^\'\"](https?|ftp|file):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[A-Z0-9+&@#\/%=~_|]/i', '<a href="\0">\0</a>', $string);
    //$string = preg_replace('/\b(http|https|ftp|ftps)\:\/\/[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,3}(\/\S*)?\b[^\"\']/', ' <a href="$0" target="_blank" title="$0">$0</a> ', $string);
    return convertHashtagsAndUserTags($text);
}

function convertHashtagsAndUserTags($str){
    $regex = "/#+([a-zA-Z0-9_]+)/";
    $str = preg_replace($regex, '<a href="hashtag.php?tag=$1">$0</a>', $str);
    $regex = "/@+([a-zA-Z0-9]+)/";
    $str = preg_replace($regex, '<a href="user.php?u=$1">$0</a>', $str);
    return($str);
}

// function makeClickableLinks($s) {
//   return preg_replace('@(https?://([-\w\.]+[-\w])+(:\d+)?(/([\w/_\.#-]*(\?\S+)?[^\.\s])?)?)@', '<a href="$1" target="_blank">$1</a>', $s);
// }
?>
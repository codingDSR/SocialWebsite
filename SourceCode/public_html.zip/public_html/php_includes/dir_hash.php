<?php
define('SALT', 'SocialWeb');
// function dir_encrypt($text)
// {
//     return trim(base64_encode(mcrypt_encrypt(MCRYPT_RIJNDAEL_256, SALT, $text, MCRYPT_MODE_ECB, mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB), MCRYPT_RAND))));
// }
// function dir_decrypt($text)
// {
//     return trim(mcrypt_decrypt(MCRYPT_RIJNDAEL_256, SALT, base64_decode($text), MCRYPT_MODE_ECB, mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB), MCRYPT_RAND)));
// }

function dir_encrypt ($stringArray, $key = "Soc") {
 $s = strtr(base64_encode(mcrypt_encrypt(MCRYPT_RIJNDAEL_256, md5($key), serialize($stringArray), MCRYPT_MODE_CBC, md5(md5($key)))), '+/=', '_12');
 return $s;
}

function dir_decrypt ($stringArray, $key = "Soc") {
 $s = unserialize(rtrim(mcrypt_decrypt(MCRYPT_RIJNDAEL_256, md5($key), base64_decode(strtr($stringArray, '_12', '+/=')), MCRYPT_MODE_CBC, md5(md5($key))), "\0"));
 return $s;
}


// function note_encrypt($sData, $sKey='mysecretkey'){ 
//     $sResult = ''; 
//     for($i=0;$i<strlen($sData);$i++){ 
//         $sChar    = substr($sData, $i, 1); 
//         $sKeyChar = substr($sKey, ($i % strlen($sKey)) - 1, 1); 
//         $sChar    = chr(ord($sChar) + ord($sKeyChar)); 
//         $sResult .= $sChar; 
//     } 
//     return encode_base64($sResult); 
// } 

// function note_decrypt($sData, $sKey='mysecretkey'){ 
//     $sResult = ''; 
//     $sData   = decode_base64($sData); 
//     for($i=0;$i<strlen($sData);$i++){ 
//         $sChar    = substr($sData, $i, 1); 
//         $sKeyChar = substr($sKey, ($i % strlen($sKey)) - 1, 1); 
//         $sChar    = chr(ord($sChar) - ord($sKeyChar)); 
//         $sResult .= $sChar; 
//     } 
//     return $sResult; 
// } 
// function encode_base64($sData){ 
//     $sBase64 = base64_encode($sData); 
//     return strtr($sBase64, '+/', '-_'); 
// } 

// function decode_base64($sData){ 
//     $sBase64 = strtr($sData, '-_', '+/'); 
//     return base64_decode($sBase64); 
// }  

    // function note_encrypt($text,$salt='Soc')
    // {  
    //     return trim(base64_encode(mcrypt_encrypt(MCRYPT_RIJNDAEL_256, $salt, $text, MCRYPT_MODE_ECB, mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB), MCRYPT_RAND))));
    // }
 
    // function note_decrypt($text,$salt='Soc')
    // {  
    //     return trim(mcrypt_decrypt(MCRYPT_RIJNDAEL_256, $salt, base64_decode($text), MCRYPT_MODE_ECB, mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB), MCRYPT_RAND)));
    // }

function note_encrypt($data) {
	$data='Dsr'.$data.'dk';
	return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function note_decrypt($data) {
	return base64_decode(str_pad(strtr($data, '-_', '+/'), strlen($data) % 4, '=', STR_PAD_RIGHT));
}

//echo $a = base64url_encode("darshan");
//echo '<br>'.base64url_decode($a);

//$encryptedmessage = encrypt("your message");
//echo decrypt($encryptedmessage);
?>

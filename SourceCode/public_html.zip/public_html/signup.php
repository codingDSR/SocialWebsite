<?php
session_start();
// If user is logged in, header them away
if(isset($_SESSION['userid'])){
	header("location: feeds.php");
    exit();
} 
?><?php
// Ajax calls this NAME CHECK code to execute
if(isset($_POST["usernamecheck"])){
	include_once("php_includes/db_conx.php");
	$username = preg_replace('#[^a-z0-9]#i', '', $_POST['usernamecheck']);
	$sql = "SELECT id FROM users WHERE username='$username' LIMIT 1";
    $query = mysqli_query($db_conx, $sql);
    $uname_check = mysqli_num_rows($query);
    if (strlen($username) < 3 || strlen($username) > 16) {
	    echo '<strong style="color:#F00;">3 - 16 characters please</strong>';
	    exit();
    }
	if (is_numeric($username[0])) {
	    echo '<strong style="color:#F00;">Usernames must begin with a letter</strong>';
	    exit();
    }
    if ($uname_check < 1) {
	    echo '<strong style="color:#009900;">' . $username . ' &#10003;</strong>';
	    exit();
    } else {
	    echo '<strong style="color:#F00;">' . $username . ' is already taken</strong>';
	    exit();
    }
}
?><?php
// Ajax calls this REGISTRATION code to execute
if(isset($_POST["u"])){
	// CONNECT TO THE DATABASE
	include_once("php_includes/db_conx.php");
	// GATHER THE POSTED DATA INTO LOCAL VARIABLES
	$u = preg_replace('#[^a-z0-9]#i', '', $_POST['u']);
	$e = mysqli_real_escape_string($db_conx, $_POST['e']);
	$p = mysqli_real_escape_string($db_conx, $_POST['p']);
	// GET USER IP ADDRESS
  $ip = preg_replace('#[^0-9.]#', '', getenv('REMOTE_ADDR'));
	// DUPLICATE DATA CHECKS FOR USERNAME AND EMAIL
	$sql = "SELECT id FROM users WHERE username='$u' LIMIT 1";
  $query = mysqli_query($db_conx, $sql);
	$u_check = mysqli_num_rows($query);
	// -------------------------------------------
	$sql = "SELECT id FROM users WHERE email='$e' LIMIT 1";
  $query = mysqli_query($db_conx, $sql);
	$e_check = mysqli_num_rows($query);
	// FORM DATA ERROR HANDLING
	if($u == "" || $e == "" || $p == ""){
		echo "The form submission is missing values.";
        exit();
	} else if ($u_check > 0){
        echo "The username you entered is alreay taken";
        exit();
	} else if ($e_check > 0){
        echo "That email address is already in use in the system";
        exit();
	} else if (strlen($u) < 3 || strlen($u) > 16) {
        echo "Username must be between 3 and 16 characters";
        exit();
    } else if (is_numeric($u[0])) {
        echo 'Username cannot begin with a number';
        exit();
    } else {
	// END FORM DATA ERROR HANDLING
	    // Begin Insertion of data into the database
		// Hash the password and apply your own mysterious unique salt
		//$cryptpass = crypt($p);
		include_once ("php_includes/randStrGen.php");
		//$p_hash = randStrGen(20)."$cryptpass".randStrGen(20);
    $p_hash = sha1($p);
		// Add user info into the database table for the main site table
		$sql = "INSERT INTO users (username, email, password, ip, signup, lastlogin, notescheck)
		        VALUES('$u','$e','$p_hash','$ip',now(),now(),now())";
		$query = mysqli_query($db_conx, $sql);
		$uid = mysqli_insert_id($db_conx);
		// Establish their row in the useroptions table
		$sql = "INSERT INTO useroptions (id, username, background) VALUES ('$uid','$u','original')";
		$query = mysqli_query($db_conx, $sql);
		// Create directory(folder) to hold each user's files(pics, MP3s, etc.)
    require_once('php_includes/dir_hash.php');
		if (!file_exists('user/'.dir_encrypt($u))) {
			mkdir('user/'.dir_encrypt($u), 0755);
		}
		// Email the user their activation link
		$to = "$e";
		$from = "verify@codingflag.in";
		$subject = 'Codingflag Account Activation';
		$message = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Codingflag account activation</title></head><body style="margin:0px; font-family:Tahoma, Geneva, sans-serif;"><div style="padding:10px; background:#151719; font-size:24px; color:#CCC;"><a href="http://www.codingflag.in"><img src="https://www.codingflag.in/images/logo.png" width="36" height="30" alt="yoursitename" style="border:none; float:left;"></a> &nbsp;Codingflag Account Activation</div><div style="padding:24px; font-size:17px;">Hello '.$u.',<br /><br />Click the link below to activate your account when ready:<br /><br /><a href="https://www.codingflag.in/activation.php?id='.$uid.'&u='.$u.'&e='.$e.'&unique='.$p_hash.'">Click here to activate your account now</a><br /><br />Login after successful activation using your:<br />* E-mail Address: <b>'.$e.'</b></div></body></html>';
		$headers = "From: $from\n";
        $headers .= "MIME-Version: 1.0\n";
         $headers .= "Content-type: text/html; charset=iso-8859-1\n";
		 mail($to, $subject, $message, $headers);
		echo "signup_success";
		exit();
	}
	exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta name="description" content="">
    <meta name="author" content="">
	<style>
		@import url('https://fonts.googleapis.com/css?family=Dosis:400,600|Open+Sans:300,400,600|Roboto:300,400,500');
	</style>
	<link rel="icon" href="favicon.ico" type="image/x-icon">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="js/main.js"></script>
	<script src="js/ajax.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<title>Sign Up</title>
<link rel="stylesheet" href="style/style.css">
<style type="text/css">
body {font-size:15px}
.container {margin-top:125px;}
#loginform .form-control { margin-top:13px;margin-bottom:15px; }
#loginform button { background:#00acee;padding:8px;font-size:18px; }
#loginform input {height: 38px;padding: 12px;background: transparent; }
::-webkit-input-placeholder { /* Chrome/Opera/Safari */
  font-weight:600;
  color:rgb(120,120,120);
}
::-moz-placeholder { /* Firefox 19+ */
  font-weight:600;
  color:rgb(120,120,120);
}
:-ms-input-placeholder { /* IE 10+ */
  font-weight:600;
  color:rgb(120,120,120);
}
:-moz-placeholder { /* Firefox 18- */
  font-weight:600;
  color:rgb(120,120,120);
}
.container .row h3 {margin-bottom:35px;}
@media only screen and (max-width: 500px) {
.container .row h3 {font-size:20px;}
.container {margin-top:80px;}
}
</style>
<script src="js/main.js"></script>
<script src="js/ajax.js"></script>
<script>
function emptyElement(x){
  _(x).innerHTML = "";
}
window.onload = function(){
  const usernameRef = _('username');
  if (usernameRef.addEventListener) {
      usernameRef.addEventListener("blur", checkusername);
      usernameRef.addEventListener("keyup", function(){
        restrict('username');
      });
  } else if (x.attachEvent) {
      usernameRef.attachEvent("blur", checkusername);
      usernameRef.attachEvent("keyup", function(){
        restrict('username');
      });
  }
};
const trim = function(txt) {
	return txt.replace(/^\s+|\s+$/g,"");
}
const ValidateEmail = function (mail) {
  return !(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail));
}
const restrict =  function (elem){
	var tf = _(elem);
	var rx = new RegExp;
	if(elem == "email"){
		rx = /[' "]/gi;
	} else if(elem == "username"){
		rx = /[^a-z0-9]/gi;
	}
	tf.value = tf.value.replace(rx, "");
}

function checkusername(){
	var u = trim(_("username").value);
	if(u != ""){
		_("unamestatus").innerHTML = 'checking ...';
		var ajax = ajaxObj("POST", "signup.php");
        ajax.onreadystatechange = function() {
	        if(ajaxReturn(ajax) == true) {
	            _("unamestatus").innerHTML = ajax.responseText;
	        }
        }
        ajax.send("usernamecheck="+u);
	}
}
const signup = function (){
	var u = trim(_("username").value);
	var e = trim(_("email").value);
	var p1 = _("pass1").value;
  var status = _("status");
	if(u == "" || e == "" || p1 == ""){
		status.innerHTML = "You must fill in all of the fields.";
    return ;
	} else if(ValidateEmail(e)){
    status.innerHTML = "Enter Valid Email Address.";
    return ;
  } else if(p1.length > 16 || p1.length < 6){
    status.innerHTML = "password (length between 6 to 16 characters)";
    return ;
  } else {
		_("signupbtn").style.display = "none";
		status.innerHTML = 'please wait ...';
		var ajax = ajaxObj("POST", "signup.php");
        ajax.onreadystatechange = function() {
	        if(ajaxReturn(ajax) == true) {
            //alert(ajax.responseText);
	            if(ajax.responseText != "signup_success"){
					status.innerHTML = ajax.responseText;
					_("signupbtn").style.display = "block";
				} else {
					window.scrollTo(0,0);
					_("signupform").innerHTML = "<div style=\"text-align:left;\"><p>OK "+u+", check your email inbox and junk mail box at <u>"+e+"</u> in a moment(upto 5 minutes) to complete the sign up process by activating your account. </p>You will not be able to do anything on the site until you successfully activate your account.</div>";
				}
	        }
        }
        ajax.send("u="+u+"&e="+e+"&p="+p1);
	}
}







// Object.defineProperty(window, "console", {
//     value: console,
//     writable: false,
//     configurable: false
// });

// var i = 0;
// function showWarningAndThrow() {
//     if (!i) {
//         setTimeout(function () {
//             console.log("%cWarning message", "font: 2em sans-serif; color: yellow; background-color: red;");
//         }, 1);
//         i = 1;
//     }
//     throw "Console is disabled";
// }

// var l, n = {
//         set: function (o) {
//             l = o;
//         },
//         get: function () {
//             showWarningAndThrow();
//             return l;
//         }
//     };
// Object.defineProperty(console, "_commandLineAPI", n);
// Object.defineProperty(console, "__commandLineAPI", n);

// setInterval(function(){
//   console.log("%cWarning message", "font: 2em sans-serif; color: yellow; background-color: red;");
// },1000);
//console.log("%cWarning message", "font: 2em sans-serif; color: yellow; background-color: red;");
// window.console.log = function(){
//     window.console.log = function() {
//     console.error('The developer console is blocked.');
//         return false;
//     }
// }
// window.console.dir = function(){
//     window.console.dir = function() {
//     console.error('The developer console is blocked.');
//         return false;
//     }
// }
// console.log('test');
// console.dir('test');

// var is;
// Object.defineProperty(Object.prototype,"_lastResult",{
//    get:function(){
//        return this._lR;
//    },
//    set:function(v){
//        if (typeof this._commandLineAPIImpl=="object") is=this;
//        this._lR=v;
//    }
// });
// setTimeout(function(){
//    var ev=is._evaluateAndWrap;
//    is._evaluateAndWrap=function(){
//        var res=ev.apply(is,arguments);
//        console.log();
//        if (arguments[2]==="completion") {
//            //This is the path you end up when a user types in the console and autocompletion get's evaluated

//            //Chrome expects a wrapped result to be returned from evaluateAndWrap.
//            //You can use `ev` to generate an object yourself.
//            //In case of the autocompletion chrome exptects an wrapped object with the properties that can be autocompleted. e.g.;
//            //{iGetAutoCompleted: true}
//            //You would then go and return that object wrapped, like
//            //return ev.call (is, '', '({test:true})', 'completion', true, false, true);
//            //Would make `test` pop up for every autocompletion.
//            //Note that syntax as well as every Object.prototype property get's added to that list later,
//            //so you won't be able to exclude things like `while` from the autocompletion list,
//            //unless you wou'd find a way to rewrite the getCompletions function.
//            //
//            return res; //Return the autocompletion result. If you want to break that, return nothing or an empty object
//        } else {
//            //This is the path where you end up when a user actually presses enter to evaluate an expression.
//            //In order to return anything as normal evaluation output, you have to return a wrapped object.

//            //In this case, we want to return the generated remote object. 
//            //Since this is already a wrapped object it would be converted if we directly return it. Hence,
//            //`return result` would actually replicate the very normal behaviour as the result is converted.
//            //to output what's actually in the remote object, we have to stringify it and `evaluateAndWrap` that object again.`
//            //This is quite interesting;
//            return ev.call (is, null, '(' + JSON.stringify (res) + ')', "console", true, false, true)
//        }
//    };
// },0);

  Object.getOwnPropertyNames(console).filter(function(property) {
     return typeof console[property] == 'function';
  }).forEach(function (verb) {
     console[verb] =function(){return 'Blocked, for security reasons...';};
  });


</script>
</head>
<body>


<nav class="navbar navbar-inverse navbar-fixed-top no-margin">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>
      <a class="navbar-brand" href="#">Codingflag</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="login.php">Log In</a></li>
      </ul>
    </div>
  </div>
</nav>
<!--
<div class="container">
	<div class="login-container" id="signupform">
            <div id="output"></div>
			<div style="margin-top: 10px;font-size: 18px;margin-bottom: 10px;color: #564a4a;font-weight: 600;">Register for an Account</div>
			<div style="margin-top: 5px;margin-bottom: 10px;"><img src="images/signup_user.jpg" style="width: 75px;height: 75px;"></div>			
            <div class="form-box">
                <form id="loginform" onsubmit="return false;">
                    <input onfocus="emptyElement('status')" id="username" type="text" maxlength="16" placeholder="Username"/>
                    <span id="unamestatus"></span>
                    <input onfocus="emptyElement('status')" id="email" type="email" maxlength="88" placeholder="Email ID"/>
                    <input onfocus="emptyElement('status')" placeholder="Password" id="pass1" type="password" maxlength="16"/>
                    <button type="button" id="signupbtn" onclick="signup()" class="btn btn-info btn-block login">Register</button>
                </form>
                <p id="status"></p>
            </div>
            <div style="margin-top:15px;" class="text-center">
            	<a href="login.php">Already have an account? Log In</a>
            </div>
    </div>
</div>
-->

	<div class="container">
		<div class="row">
			<div class="col-xs-12 col-sm-12 col-md-3"></div>
			<div class="col-xs-12 col-sm-12 col-md-6" id="signupform">
				<h3>Join Developers Network.<h3>
	            <div class="form-box">
	                <form id="loginform" onsubmit="return false;">
	                    <input style="margin-bottom:0px;" class="form-control" onfocus="emptyElement('status')" id="username" type="text" maxlength="16" placeholder="Username"/>
	                    <span style="font-size:15px;" id="unamestatus"></span>
	                    <input class="form-control" onfocus="emptyElement('status')" id="email" type="email" maxlength="88" placeholder="Email ID"/>
	                    <input class="form-control" onfocus="emptyElement('status')" placeholder="Password" id="pass1" type="password" maxlength="16"/>
	                    <button type="button" id="signupbtn" onclick="signup()" class="btn btn-info btn-block login">Register</button>
	                </form>
	                <p style="font-size:15px;margin-top:20px;text-align:center;" id="status"></p>
	            </div>
	            <div style="margin-top:15px;" class="">
	            	<a style="font-size:16px;" href="login.php">Already have an account? Log In</a>
	            </div>					
			</div>
			<div class="col-xs-12 col-sm-12 col-md-3"></div>
		</div>
	</div>



</body>
</html>

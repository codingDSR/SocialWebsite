<?php
include_once("php_includes/check_login_status.php");
require_once('php_includes/dir_hash.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta name="description" content="">
    <meta name="author" content="">
	<title>Edit Information</title>
	<link rel="icon" href="favicon.ico" type="image/x-icon">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
	<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>	
	<script src="js/main.js"></script>
	<style>
		@import url('https://fonts.googleapis.com/css?family=Dosis:400,600|Open+Sans:300,400,600|Roboto:300,400,500');
	</style>
	<style>

.panel-heading {
  background: #FAFAFA;
  border-bottom: 2px solid #ECECEC;
  padding: 11px 12px 9px;
  position: relative;	
}
.panel-body {
  background: #FFF;
  margin: 0;
  padding: 12px;
}	
.panel-footer {
  background: #FFF;
  border-top: 1px solid #ECECEC;
  padding-left: 12px;
  padding-right: 12px;	
}
.xyz {
	padding-left: 0px;
}
input.error,select.error,textarea.error {
	border:1px solid #ec8977;
}
	</style>
	<script type="text/javascript">
const ValidateEmail = function (mail) {
  return !(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail));
}
const trim = function(txt) {
	return txt.replace(/^\s+|\s+$/g,"");
}	
const validateForm = function(){
	var bio = trim(_('bioData').value);
	var website = trim(_('Website').value);
	var city = trim(_('city').value);
	var gender = trim(_('gender').value);
	if(bio == '' && website == '' && city == '' && gender == ''){
		_('bioData').classList.add('error');
		_('Website').classList.add('error');
		_('city').classList.add('error');
		_('gender').classList.add('error');
		return false;
	} else {

		if(website != ''){
			var websiteRegex = /[-a-zA-Z0-9@:%_\+.~#?&//=]{2,256}\.[a-z]{2,4}\b(\/[-a-zA-Z0-9@:%_\+.~#?&//=]*)?/gi;
			if(website.match(websiteRegex))	{
			}	else {
				_('Website').classList.add('error');
				return false;
			}	
		}

		if(city != ''){
			var cityRegex = /^[a-zA-Z0-9\s,'-]*$/;
			if(cityRegex.test(city)){
			}else {
				_('city').classList.add('error');
				return false;
			}
		}

		if(gender != '' && gender != '-'){
			if(gender != "m" || gender != "f") {
			}else {
				_('gender').classList.add('error');
				return false;
			}
		} 

	}
}
function statusMax(field, maxlimit) {
	if (field.value.length > maxlimit){
		alert(maxlimit+" maximum character limit reached");
		field.value = field.value.substring(0, maxlimit);
	}
}
$(document).ready(function(){
	$('input,select,textarea').focus(function(){
		$('input').removeClass('error');
		$('select').removeClass('error');
		$('textarea').removeClass('error');
	})
})
	</script>
</head>
<body>
	<?php include_once("view_components/template_pageTop.php"); ?>
        <div id="page-content-wrapper">
        	<div class="page--header">
        		<hr>
        		<h3>Basic Information</h3>
        		<hr>
        	</div>	
            <div class="container-fluid xyz ">
            	<div class="row">
								<div class="col-xs-12 col-lg-8">
							
								                        
								  <div class="panel-heading">
								    <span class="panel-title">Basic Information</span>
								  </div>
								  <div class="panel-body">
<form action="php_parsers/update_abouts_system.php" class="panel form-horizontal" validate="true" method="post" onsubmit="return validateForm()">
								    <div class="form-group">
								      <label for="" class="col-sm-2 control-label">Bio:</label>
								      <div class="col-sm-10">
								        <textarea onkeyup="statusMax(this,500)" style="resize:none;" class="form-control require-validation" id="bioData" name="bioData"></textarea>
								      </div>
								    </div>
										<input type="hidden" name="action" value="update_data" required/>	
								    <div class="form-group">
								      <label for="" class="col-sm-2 control-label">Website:</label>
								      <div class="col-sm-10">
								        <input type="text" class="form-control require-validation" id="Website" name="Website" />
								      </div>
								    </div>

								    <div class="form-group">
								      <label for="" class="col-sm-2 control-label">City:</label>
								      <div class="col-sm-10">
								        <input type="text" class="form-control require-validation" id="city" name="city" maxlength="50"/>
								      </div>
								    </div>

								    <!-- Gender -->
								    <div class="form-group form-group-container">
								      <label for="" class="col-sm-2 control-label">Gender:</label>
								      <div class="col-sm-10">
								          <select name="gender" id="gender" class="form-control form-item">
								            <option value="">-</option>
								            <option value="m">Male</option>
								            <option value="f">Female</option>    
								          </select>
								      </div>
								    </div>


								    <!-- Submit button -->
								    <div class="panel-footer">
								      <div class="row">
								        <div class="col-sm-offset-2 col-sm-8">
								         <button type="submit" class="btn btn-primary">
								         	Submit
								         </button>
								        </div>
								      </div>
								    </div>

							</form>
								  </div>
								</div>  						
            </div>
          </div>
        </div>
    </div>
	<?php include_once("view_components/template_pageBottom.php"); ?>
	<script src="js/sidebar_menu.js"></script>
</body>
</html>
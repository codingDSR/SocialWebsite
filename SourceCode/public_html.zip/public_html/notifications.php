<?php
include_once("php_includes/check_login_status.php");
// If the page requestor is not logged in, usher them away
if($user_ok != true || $log_username == ""){
	header("location: login.php");
    exit();
} else {
	require_once('php_includes/dir_hash.php');
}
//Total Notes 
$sql = "SELECT COUNT(n.id) FROM notifications n WHERE user_id LIKE BINARY '$log_id'";
$query = mysqli_query($db_conx, $sql);
$total_notes_num_row = mysqli_fetch_row($query);
$total_notes = $total_notes_num_row[0];



$notification_list = "";
$sql = "SELECT n.*,u.username,u.avatar FROM notifications n,users u WHERE user_id LIKE BINARY '$log_id'AND n.initiator_id=u.id ORDER BY date_time DESC LIMIT 30";
$query = mysqli_query($db_conx, $sql);
$numrows = mysqli_num_rows($query);
if($numrows < 1){
	$notification_list = "&nbsp; You do not have any notifications";
} else {
	while ($row = mysqli_fetch_array($query, MYSQLI_ASSOC)) {
		$noteid = $row["id"];
		$initiator = $row["username"];
		$avatar = $row["avatar"];
		$app = $row["app"];
		$note = $row["note"];
		$did_read = $row["did_read"];
		$date_time = $row["date_time"];
		$date_time = strftime("%b %d, %Y", strtotime($date_time));
		$profile_pic = '<img src="user/'.dir_encrypt($initiator).'/'.$avatar.'" alt="'.$initiator.'">';
		if($avatar == NULL){
			//$profile_pic = '<img src="images/avatardefault.jpg">';
			$profile_pic = '<img src="images/avatardefault.jpg" alt="'.$initiator.'">';
		}
		if($did_read == '0'){
			if($app == "Status Post" || $app == "Status Reply"){
				if($app == "Status Post") {
					$notification_list .= "<div data-app=\"typea\" data-note=\"$note\" data-nid=\"$noteid\" onclick=\"openNote(this)\" class=\"note\">$profile_pic<div class=\"note-data\"><a href=\"user.php?u=$initiator\">$initiator</a> posted new status.</div></div>";
				} else {
					$notification_list .= "<div data-app=\"typea\" data-note=\"$note\" data-nid=\"$noteid\" onclick=\"openNote(this)\" class=\"note\">$profile_pic<div class=\"note-data\"><a href=\"user.php?u=$initiator\">$initiator</a> commented here.<br>Click here to see conversation.</div></div>";
				}
			} else {
				$notification_list .= "<div data-app=\"typeb\" data-note=\"$initiator\" data-nid=\"$noteid\" onclick=\"openNote(this)\" class=\"note\">$profile_pic<div class=\"note-data\">$note</div></div>";
			}			
		} else if ($did_read == '1'){
			if($app == "Status Post" || $app == "Status Reply"){
				if($app == "Status Post") {
					$notification_list .= "<div data-app=\"typea\" data-note=\"$note\" data-nid=\"$noteid\" onclick=\"openNote(this)\" class=\"note readed\">$profile_pic<div class=\"note-data\"><a href=\"user.php?u=$initiator\">$initiator</a> posted new status.</div></div>";
				} else {
					$notification_list .= "<div data-app=\"typea\" data-note=\"$note\" data-nid=\"$noteid\" onclick=\"openNote(this)\" class=\"note readed\">$profile_pic<div class=\"note-data\"><a href=\"user.php?u=$initiator\">$initiator</a> commented here.<br>Click here to see conversation.</div></div>";
				}
			} else {
				$notification_list .= "<div data-app=\"typeb\" data-note=\"$initiator\" data-nid=\"$noteid\" onclick=\"openNote(this)\" class=\"note readed\">$profile_pic<div class=\"note-data\">$note</div></div>";
			}			
		}

		
	}
}
// mysqli_query($db_conx, "UPDATE users SET notescheck=now() WHERE username='$log_username' LIMIT 1");
?>

<?php
// $friend_requests = "";
// $sql = "SELECT f.*,u.username as 'user1_name',u.avatar as 'user_avatar' FROM friends f,users u WHERE user2_id='$log_id' AND accepted='0' AND f.user1_id=u.id ORDER BY datemade ASC";
// $query = mysqli_query($db_conx, $sql);
// $numrows = mysqli_num_rows($query);
// if($numrows < 1){
// 	$friend_requests = 'No friend requests';
// } else {
// 	while ($row = mysqli_fetch_array($query, MYSQLI_ASSOC)) {
// 		$reqID = $row["id"];
// 		$user1 = $row["user1_id"];
// 		$user1_name = $row["user1_name"];
// 		$datemade = $row["datemade"];
// 		$datemade = strftime("%B %d", strtotime($datemade));
// 		//$thumbquery = mysqli_query($db_conx, "SELECT avatar FROM users WHERE id='$user1' LIMIT 1");
// 		//$thumbrow = mysqli_fetch_row($thumbquery);
// 		$user1avatar = $row["user_avatar"];		
// 		if($user1avatar == NULL){
// 			$user1pic = '<img src="images/avatardefault.jpg" alt="'.$user1.'" class="user_pic">';
// 		} else {
// 			$user1pic = '<img src="user/'.dir_encrypt($user1_name).'/'.$user1avatar.'" alt="'.$user1.'" class="user_pic">';
// 		}
// 		$friend_requests .= '<div id="friendreq_'.$reqID.'" class="friendrequests">';
// 		$friend_requests .= '<a href="user.php?u='.$user1_name.'">'.$user1pic.'</a>';
// 		$friend_requests .= '<div class="user_info" id="user_info_'.$reqID.'">'.$datemade.' <a href="user.php?u='.$user1_name.'">'.$user1_name.'</a> requests friendship<br /><br />';
// 		$friend_requests .= '<button onclick="friendReqHandler(\'accept\',\''.$reqID.'\',\''.$user1.'\',\'user_info_'.$reqID.'\')">accept</button> or ';
// 		$friend_requests .= '<button onclick="friendReqHandler(\'reject\',\''.$reqID.'\',\''.$user1.'\',\'user_info_'.$reqID.'\')">reject</button>';
// 		$friend_requests .= '</div>';
// 		$friend_requests .= '</div>';
// 	}
// }
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta name="description" content="">
    <meta name="author" content="">
	<style>
		@import url('https://fonts.googleapis.com/css?family=Dosis:400,600|Open+Sans:300,400,600|Roboto:300,400,500');
	</style>
	<link rel="icon" href="favicon.ico" type="image/x-icon">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="js/main.js"></script>
	<script src="js/ajax.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
	<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
	<title>Notifications and Friend Requests</title>
<style type="text/css">
/*div#notesBox{float:left; width:430px; border:#F0F 1px dashed; margin-right:60px; padding:10px;}
div#friendReqBox{float:left; width:430px; border:#F0F 1px dashed; padding:10px;}
div.friendrequests{height:74px; border-bottom:#CCC 1px solid; margin-bottom:8px;}
img.user_pic{float:left; width:68px; height:68px; margin-right:8px;}
div.user_info{float:left; font-size:14px;}*/
.note:nth-child(1) {
	border-top: 1px solid #ddd;
}
.note {
	min-height: 85px;
    border: 1px solid #ddd;
    border-top: none;
    background: #ebebeb;
    padding: 6px 10px;	
    cursor: pointer;
}
.note.readed {
	background: #fbfbfb;
}
.note img {
    width: 70px;
    height: 70px;
    float: left;	
}
.note .note-data {
	padding-left: 85px;
}
</style>
<script type="text/javascript">
const total_notes = <?php echo $total_notes; ?>;
function openNote(ref){
	if(typeof ref == null || typeof ref == undefined){
		return;
	} else {
		var nid = parseInt(ref.getAttribute('data-nid'));
		var note = ref.getAttribute('data-note');
		var app = ref.getAttribute('data-app');
		if(typeof nid != "number"){
			return ;
		}
		var link = '';
		if(app == 'typea'){
			link = 'post.php?pid='+note;
		} else {
			link = 'user.php?u='+note;
		}
		var ajax = ajaxObj("POST", "php_parsers/mark_notes_system.php");
		ajax.onreadystatechange = function() {
			if(ajaxReturn(ajax) == true) {
				if(ajax.responseText == "mark_ok"){
					window.location.assign(link);
				} else {
					window.location.assign(link);
				}
			}
		}
		ajax.send("action=mark_read_note&noteid="+nid);


	}
}
</script>
</head>
<body>
	<?php include_once("view_components/template_pageTop.php"); ?>
        <div id="page-content-wrapper">
        	<div class="page--header">
        		<hr>
        		<h3>Notifications</h3>
        		<hr>
        	</div>			
            <div class="container-fluid xyz row">
            	<div class="row">
					<div class="col-xs-12 col-sm-12 col-md-8" id="profile-posts-tab">
						<div id="notesBox">
						  <?php echo $notification_list; ?>
						</div>	
					</div>            		
					<div class="col-xs-12 col-sm-12 col-md-4"></div>
            	</div>
            </div>
        </div>
    </div>
	<?php include_once("view_components/template_pageBottom.php"); ?>

	<script src="js/sidebar_menu.js"></script>
	<script type="text/javascript">
$(document).ready(function(){
	$('.sidebar-nav li').eq(3).addClass('active');
});
	</script>
</body>
</html>

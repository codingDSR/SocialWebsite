<?php
// It is important for any file that includes this file, to have
// check_login_status.php included at its very top.
if($user_ok == true) {
    $notes_nums = 0;
    $requests_nums = 0;
	$sql = "SELECT notescheck FROM users WHERE username='$log_username' LIMIT 1";
	$query = mysqli_query($db_conx, $sql);
	$row = mysqli_fetch_row($query);
	$notescheck = $row[0];
	$sql = "SELECT COUNT(id) FROM notifications WHERE user_id='$log_id' AND date_time > '$notescheck' AND did_read='0' LIMIT 99";
	$query = mysqli_query($db_conx, $sql);
	$notes_nums_row = mysqli_fetch_row($query);
    $notes_nums = $notes_nums_row[0]; 

    $sql = "SELECT COUNT(id) FROM friends WHERE user2_id='$log_id' AND accepted='0' LIMIT 99";
    $query = mysqli_query($db_conx, $sql);
    $requests_nums_row = mysqli_fetch_row($query);
    $requests_nums = $requests_nums_row[0]; 

 //    if ($numrows == 0) {
	// 	$envelope = '<a href="notifications.php" title="Your notifications and friend requests"><img src="images/note_still.jpg" width="22" height="12" alt="Notes"></a>';
 //    } else {
	// 	$envelope = '<a href="notifications.php" title="You have new notifications"><img src="images/note_flash.gif" width="22" height="12" alt="Notes"></a>';
	// }
 //    $loginLink = '<a href="user.php?u='.$log_username.'">'.$log_username.'</a> &nbsp; | &nbsp; <a href="logout.php">Log Out</a>';
}
?>
<link rel="stylesheet" href="style/style.css">  
<style type="text/css">
<?php 
if(!isset($_SESSION["username"])){
    echo '#wrapper {padding-left: 0px !important; }';
    echo '#sidebar-wrapper {display:none !important;}';
}
?>    
</style>
<!--     <nav class="navbar navbar-default no-margin navbar-fixed-top">
    
                <div class="navbar-header fixed-brand">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"  id="menu-toggle">
                      <span class="glyphicon glyphicon-th-large" aria-hidden="true"></span>
                    </button>
                    <a class="navbar-brand" href="#"><i class="fa fa-rocket fa-4"></i> SEEGATESITE</a>        
                </div>

                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                            <ul class="nav navbar-nav">
                                <li class="active" ><button class="navbar-toggle collapse in" data-toggle="collapse" id="menu-toggle-2"> <span class="glyphicon glyphicon-th-large" aria-hidden="true"></span></button></li>
                            </ul>
                </div>
    </nav> -->
<nav class="navbar navbar-inverse no-margin navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" style="border:none;" class="navbar-toggle navbar-toggle collapse in" data-toggle="collapse" id="menu-toggle">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>
      <a class="navbar-brand" href="index.php">Codingflag</a>
    </div>
<!--     <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li class="active" ><button class="navbar-toggle collapse in" data-toggle="collapse" id="menu-toggle-2"> <span class="glyphicon glyphicon-th-large" aria-hidden="true"></span></button></li>
      </ul>
    </div> -->
  </div>
</nav>

    <div id="wrapper" class="">
        <!-- Sidebar -->
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav nav-pills nav-stacked" id="menu">

<!--                 <li class="active">
                    <a href="#"><span class="fa-stack fa-lg pull-left"><i class="fa fa-pencil-square-o fa-stack-1x"></i></span> Post Status</a>
                       <ul class="nav-pills nav-stacked" style="list-style-type:none;">
                        <li><a href="#">link1</a></li>
                        <li><a href="#">link2</a></li>
                    </ul>
                </li> -->
 <!--                <li>
                    <a href="#"><span class="fa-stack fa-lg pull-left"><i class="fa fa-flag fa-stack-1x "></i></span> Shortcut</a>
                    <ul class="nav-pills nav-stacked" style="list-style-type:none;">
                        <li><a href="#"><span class="fa-stack fa-lg pull-left"><i class="fa fa-flag fa-stack-1x "></i></span>link1</a></li>
                        <li><a href="#"><span class="fa-stack fa-lg pull-left"><i class="fa fa-flag fa-stack-1x "></i></span>link2</a></li>

                    </ul>

                </li> -->
                
                <?php 
                    if(isset($log_id) && (!empty($log_id))){
                    $res = mysqli_query($db_conx,"SELECT avatar FROM users WHERE id='$log_id' LIMIT 1");
                    while($row=mysqli_fetch_array($res)){
                        $log_user_avatar = $row["avatar"];
                    }
                    $log_profile_pic = '<img style="cursor:pointer;" onclick="window.location.assign(\'user.php?u='.$log_username.'\')" src="user/'.dir_encrypt($log_username).'/'.$log_user_avatar.'" alt="'.$log_username.'">';
                    if($log_user_avatar == NULL){
                        //$profile_pic = '<img src="images/avatardefault.jpg">';
                        $log_profile_pic = '<img style="cursor:pointer;" onclick="window.location.assign(\'user.php?u='.$log_username.'\')" src="images/avatardefault.jpg" alt="'.$log_username.'">';
                    }   
                    echo '<li class="row" style="padding-top:10px;padding-bottom: 10px;margin-top:50px;border-bottom:2px groove #2e333b;"><div style="float:left;padding-left:15px;">'.$log_profile_pic.'</div><div style="display:inline;"><h3>'.$log_username.'</h3></div></li>';                 
                    }
                ?>
                <li>
                    <a href="user.php?u=<?php echo $log_username;?>"><span class="fa-stack fa-lg pull-left"><i class="fa fa-user fa-stack-1x "></i></span><span class="txt-label">Profile</span></a>
                </li>
                <li>
                    <a href="feeds.php"><span class="fa-stack fa-lg pull-left"><i class="fa fa-rss fa-stack-1x "></i></span><span class="txt-label">Feeds</span></a>
                </li>
                <li>
                    <a href="notifications.php"><span class="fa-stack fa-lg pull-left"><i class="fa fa-globe fa-stack-1x "></i></span><span class="txt-label">Notifications</span> <span class="disp-nums">(<?php echo $notes_nums; ?>)</span></a>
                </li>                
                <li>
                    <a href="requests.php"> <span class="fa-stack fa-lg pull-left"><i class="fa fa-user-plus fa-stack-1x "></i></span><span class="txt-label">Friend Requests</span> <span class="disp-nums">(<?php echo $requests_nums; ?>)</span></a>
                </li>
                <li>
                    <a href="search.php"><span class="fa-stack fa-lg pull-left"><i class="fa fa-search fa-stack-1x "></i></span><span class="txt-label">Search</span></a>
                </li>
<!--                 <li>
                    <a href="#"><span class="fa-stack fa-lg pull-left"><i class="fa fa-wrench fa-stack-1x "></i></span><span class="txt-label">Settings</span></a>
                </li> -->
                <li>
                    <a href="logout.php"><span class="fa-stack fa-lg pull-left"><i class="fa fa-power-off fa-stack-1x "></i></span><span class="txt-label">Logout</span></a>
                </li>                
            </ul>
        </div>







<div class="clear"></div>
<script type="text/javascript">
<?php 
if ($log_username != 'dsr') {
	echo 'document.addEventListener("contextmenu", function(e){e.preventDefault();}, false);';
};
?>

</script>


<div class="boxes" style="display:none;opacity:0;">
	<link rel="stylesheet" href="style/jbox.css"/>
	<script src="js/jbox.js"></script>
	<script type="text/javascript">
const alertModal = new jBox('Modal').setContent('My Content');
const alert = function(message) { 
	alertModal.setContent(message);
    alertModal.open();
} 
$(document).ready(function() {

$('#Notice-3').click(function() {

  new jBox('Notice', {
    theme: 'NoticeFancy',
    attributes: {
      x: 'left',
      y: 'bottom'
    },
    color: getColor(),
    content: 'Hello, I\'m down here',
    audio: '../Source/audio/bling2',
    volume: 80,
    animation: {open: 'slide:bottom', close: 'slide:left'}
  });
  
});


$('#Notice-NoInternet').click(function() {
  
  new jBox('Notice', {
    attributes: {
      x: 'right',
      y: 'bottom'
    },
    stack: false,
    animation: {
      open: 'tada',
      close: 'zoomIn'
    },
    color: 'red',
    title: 'Unable to connect',
    content: 'Problem with Internet Access.<br>Please check your Internet connection.'
  });
  
});


var colors = ['red', 'green', 'blue', 'yellow'], index = 0;
var getColor = function () {
  (index >= colors.length) && (index = 0);
  return colors[index++];
};


});
	</script>
	<div class="targets-wrapper">
		<div id="Notice-3" class="target-notice">Click me</div>
		<div id="Notice-NoInternet" class="target-notice">Click me</div>
	</div>
</div>

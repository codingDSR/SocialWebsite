<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta name="description" content="">
    <meta name="author" content="">
	<style>
		@import url('https://fonts.googleapis.com/css?family=Dosis:400,600|Open+Sans:300,400,600|Roboto:300,400,500');
	</style>
	<link rel="icon" href="favicon.ico" type="image/x-icon">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="style/style.css">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
	<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
	<script src="js/main.js"></script>
	<script src="js/ajax.js"></script>	
	<title>Page not found.</title>
	<style>
@import url('https://fonts.googleapis.com/css?family=Oswald:400,500|Pontano+Sans');
.text-center{text-align:center;}
.err-404 {
  margin-top: 130px;
  width:100%;
  padding: 5px;
  overflow: hidden;
  height: 350px;
}
.err-404 img{
  width:260px;
}
.err-404 h2 {
  color:rgb(120,100,100);
  font-size:28px;
  font-family: 'Oswald', sans-serif;
  margin-top:15px;
  margin-bottom:10px;
}
.err-404 p {
  color:rgb(32,32,32);
  font-size:17px;
  font-family: 'Pontano Sans', sans-serif;
}
.err-404 a {  
  position:relative;
  top:16px;
  padding:10px 18px;
  font-size:16px;
  background:#55acee;
  color:#eee;
  text-decoration:none;
  font-family:sans-serif;
  border-radius:2px;
  border:1px solid #55acee;
}
	</style>
</head>
<body>
	<?php include_once("view_components/template_pageTop.php"); ?>
        <div id="page-content-wrapper">		
            <div class="container-fluid xyz row">
            	<div class="row">
					<div class="text-center err-404">
					  <img src="images/pagenotfound.png" alt="404"/>
					  <h2>Oops! That page doesn't exist.</h2>
					  <p>The link you followed may be broken, or page may have been removed.</p>
					  <a href="index.php">&larr; &nbsp;Return to Home</a>
					</div>            		
            	</div>
            </div>
        </div>
    </div>
	<?php include_once("view_components/template_pageBottom.php"); ?>
</body>
</html>

<?php
//require('./php_includes/db_conx.php');
$status_ui = "";
$statuslist = "";
// if($isOwner == "yes"){
// 	$status_ui = '<textarea class="form-control" id="statustext" onkeyup="statusMax(this,250)" placeholder="What&#39;s new with you '.$u.'?"></textarea>';
// 	$status_ui .= '<button id="statusBtn" onclick="postToStatus(\'status_post\',\'a\',\''.$u.'\',\'statustext\')">Post</button>';
// } else if($isFriend == true && $log_username != $u){
// 	//$status_ui = '<textarea class="form-control" id="statustext" onkeyup="statusMax(this,250)" placeholder="Hi '.$log_username.', say something to '.$u.'"></textarea>';
// 	//$status_ui .= '<button id="statusBtn" onclick="postToStatus(\'status_post\',\'c\',\''.$u.'\',\'statustext\')">Post</button>';
// }

if($isOwner == "yes"){
	$status_ui = '<textarea class="form-control" id="statustext" onkeyup="statusMax(this,1500)" placeholder="What&#39;s new with you '.$u.'?"></textarea>';
	$status_ui .= '<div id="uploadDisplay_SP"></div>';
	$status_ui .= '<div id="btns_SP" class="">';
		$status_ui .= '<button class="btn button-lg button-primary" id="statusBtn" onclick="postToStatus(\'status_post\',\'a\',\''.$u.'\',\'statustext\')">Post</button>';
		$status_ui .= '<button id="triggerBtn_SP" class="btn button-lg button-primary triggerBtn" onclick="triggerUpload(event, \'fu_SP\')" >Attach Photo</button>';
		$status_ui .= '<input id="public_private_post" data-toggle="toggle" data-on="Private" data-off="Public" type="checkbox" data-toggle="toggle" data-width="100">';
	$status_ui .= '</div>';
	$status_ui .= '<div id="standardUpload" class="hiddenStuff">';
		$status_ui .= '<form id="image_SP" enctype="multipart/form-data" method="post">';
		$status_ui .= '<input type="file" name="FileUpload" id="fu_SP" onchange="doUpload(\'fu_SP\')"/>';
		$status_ui .= '</form>';
	$status_ui .= '</div>';
} else if($isFriend == true && $log_username != $u){
	// $status_ui = '<textarea id="statustext" onkeyup="statusMax(this,250)" onfocus="showBtnDiv()" placeholder="Hi '.$log_username.', say something to '.$u.'"></textarea>';
	// $status_ui .= '<div id="uploadDisplay_SP"></div>';
	// $status_ui .= '<div id="btns_SP" class="hiddenStuff">';
	// 	$status_ui .= '<button id="statusBtn" onclick="postToStatus('status_post','c',''.$u.'','statustext')">Post</button>';
	// 	$status_ui .= '<img src="images/camera.JPG" id="triggerBtn_SP" class="triggerBtn" onclick="triggerUpload(event, 'fu_SP')" width="137" height="22" title="Upload A Photo" />';
	// $status_ui .= '</div>';
	// $status_ui .= '<div id="standardUpload" class="hiddenStuff">';
	// 	$status_ui .= '<form id="image_SP" enctype="multipart/form-data" method="post">';
	// 	$status_ui .= '<input type="file" name="FileUpload" id="fu_SP" onchange="doUpload('fu_SP')"/>';
	// 	$status_ui .= '</form>';
	// $status_ui .= '</div>';
}

?><?php

// $res = mysqli_query($db_conx,"SELECT id FROM users WHERE username='$u' LIMIT 1");
// if(mysqli_num_rows($res)>0){
// 	$row = mysqli_fetch_array($res);
// 	$user_id = $row["id"];
// } else {
// 	echo "No Such User";
// 	die();
// }

$user_id = $profile_id;
$photos_gallery = '';
$total_photos = '0';

$sql = "SELECT COUNT(id) as counts FROM status WHERE account_id='$user_id' AND type NOT IN ('b','d') AND postimage IS NOT NULL";
$query = mysqli_query($db_conx, $sql);
$row = mysqli_fetch_row($query);
$total_photos = $row[0];


$sql = "SELECT postimage FROM status 
			WHERE 
				account_id='$user_id' 
				AND 
				type NOT IN ('b','d')
				AND 
				postimage IS NOT NULL
			ORDER BY postdate DESC 
			LIMIT 20";
$query = mysqli_query($db_conx, $sql);
while ($row = mysqli_fetch_array($query, MYSQLI_ASSOC)) {
	$photos_gallery .= '<li><img class="img-responsive" src="permUploads/'.$row["postimage"].'"/></li>';
}

$total_rows_sql="SELECT count(s.id)
				FROM status s
				WHERE 
					account_id='$user_id' 
					AND 
					type NOT IN ('b','d')
";
$total_rows_query = mysqli_query($db_conx, $total_rows_sql);
$total_status_row = mysqli_fetch_row($total_rows_query);
$total_status_nums = $total_status_row[0];


$oneStatusBlock = ''; 
if($log_username == $u) {
	$sql = "SELECT s.*,u.username,u.avatar 
			FROM status s,users u 
			WHERE 
				account_id='$user_id' 
				AND 
				type NOT IN ('b')
				AND
				s.author_id=u.id 
			ORDER BY postdate DESC 
			LIMIT 20";
} else {
	$sql = "SELECT s.*,u.username,u.avatar 
			FROM status s,users u 
			WHERE 
				account_id='$user_id' 
				AND 
				type NOT IN ('b','d')
				AND
				s.author_id=u.id 
			ORDER BY postdate DESC 
			LIMIT 20";	
}


$query = mysqli_query($db_conx, $sql);
$statusnumrows = mysqli_num_rows($query);
while ($row = mysqli_fetch_array($query, MYSQLI_ASSOC)) {
	$statusid = $row["id"];
	$account_name = $row["account_id"];
	$author = $row["author_id"];
	$author_name = $row["username"];
	$author_avatar = $row["avatar"];
	//$postdate = date_format($row["postdate"],"Y/m/d");
	$postdate = date('M d, Y', strtotime($row["postdate"]));
	$data = $row["data"];
	$data = nl2br($data);
	$data = str_replace("&amp;","&",$data);
	$data = makeClickableLinks(convertYoutube(stripslashes($data)));

	// Status Likes Code
	$likedStatus = '';
	$likers_profile_pic = '';
	$total_likes = '';
	$likers_tray_html = '';
	$row = mysqli_fetch_row(mysqli_query($db_conx, "SELECT COUNT(id) FROM likes WHERE status_id='$statusid'"));
	$total_likes = intval($row[0]);	

	if($total_likes > 0) {
		$Likers_tray_sql = "SELECT u.avatar,u.username FROM likes l,users u WHERE status_id='$statusid' AND l.liker_id=u.id  ORDER BY l.id DESC LIMIT 5";		
		if($total_likes > 5) {
			$likers_tray_html .= '<a class="moreLikers">+'.($total_likes-5).'</a>'; 
		}
		$Likers_tray_query = mysqli_query($db_conx, $Likers_tray_sql);
		while($r=mysqli_fetch_array($Likers_tray_query)){ 
			if($r["avatar"] == NULL){
				$likers_tray_html .='<img onclick="window.location.assign(\'user.php?u='.$r["username"].'\')" src="images/avatardefault.png"/>';
			} else {
				$likers_tray_html .='<img onclick="window.location.assign(\'user.php?u='.$r["username"].'\')" src="user/'.dir_encrypt($r["username"]).'/'.$r["avatar"].'"/>';
			}
		}
	}

	$is_liked_post_query = "SELECT id FROM likes WHERE liker_id='$log_id' AND status_id='$statusid' LIMIT 1";
	if(mysqli_num_rows(mysqli_query($db_conx,$is_liked_post_query)) > 0) {
		$likedStatus = true;
	}
	if($likedStatus == true){
		//$total_likes_query = "SELECT count(id) FROM likes WHERE status_id='$statusid'";
		// while($lrow = mysqli_fetch_array(mysqli_query($db_conx,$total_likes_query))){
		// 	$total_likes = $lrow[0];
		// }
	}
	// if($total_likes > 1) {
	// 	$likers_query = "SELECT u.username,u.avatar FROM likes l,users u WHERE l.status_id='$statusid' AND l.user_id=u.id ORDER BY id DESC LIMIT 5";
	// 	while($lkrow = mysqli_fetch_array(mysqli_query($db_conx,$likers_query))){
	// 		$liker = $lkrow["username"];
	// 		$liker_avatar = $lkrow["avatar"];
	// 	    if($liker_avatar == NULL){
	// 	        $likers_profile_pic .= '<img src="images/avatardefault.jpg" alt="'.$liker.'">';
	// 	    } else {
	// 	    	$likers_profile_pic .= '<img src="user/'.dir_encrypt($liker).'/'.$liker_avatar.'" alt="'.$liker.'">';
	// 	    }			
	// 	}
	// }
	$statusLikeButton = '';	
	if($log_username != "" && ($isFriend == true || $author==$log_id)){
		$statusLikeButton .= '<div class="likebtn row">';
		$statusLikeButton .= '<div class="col-xs-2 col-sm-2 col-md-2">';
		if($likedStatus == true){
			$statusLikeButton .= '<button data-lkd="_y_" data-std="'.$statusid.'" onclick="likeOrUnlikeStatus(\''.$statusid.'\',this);" class="btn liked">+1</button>';
		} else {
			$statusLikeButton .= '<button data-lkd="_n_" data-std="'.$statusid.'" onclick="likeOrUnlikeStatus(\''.$statusid.'\',this);" class="btn">+1</button>';
		}
		$statusLikeButton .= '</div>';
		$statusLikeButton .= '<div class="col-xs-10 col-sm-10 col-md-10" id="likers_tray_'.$statusid.'">';
		$statusLikeButton .= $likers_tray_html;
		//$statusLikeButton .= '<a class="moreLikers">+102</a>';
		//$statusLikeButton .= '<img src="user/fVjtXEV0MPvfZrbG0nb2IvjTaohdjFZe4MNhtgkdQp02/-328886068.jpg"/><img src="images/avatardefault.jpg"/>';
		$statusLikeButton .= '</div>';
		$statusLikeButton .= '</div>';
	}


	// Delete Btn Code
	$statusDeleteButton = '';
	if($author == $log_id || $account_name == $log_username){
		//$statusDeleteButton = '<span id="sdb_'.$statusid.'"><a href="#" onclick="return false;" onmousedown="deleteStatus(\''.$statusid.'\',\'status_'.$statusid.'\');" title="DELETE THIS STATUS AND ITS REPLIES"><i class="fa fa-trash-o" aria-hidden="true"> &nbsp;Delete</a></span> &nbsp; &nbsp;';
		$statusDeleteButton = '<a href="#" onclick="return false;" onmousedown="deleteStatus(\''.$statusid.'\',\'status_'.$statusid.'\');" title="DELETE THIS STATUS AND ITS REPLIES"><i class="fa fa-trash-o" aria-hidden="true"></i> &nbsp;Delete</a>';
	}
	
	// Report Btn Code
	$statusReportButton = '';
	if($log_username != "" && $author != $log_id && $account_name != $log_username){
		//$statusDeleteButton = '<span id="sdb_'.$statusid.'"><a href="#" onclick="return false;" onmousedown="deleteStatus(\''.$statusid.'\',\'status_'.$statusid.'\');" title="DELETE THIS STATUS AND ITS REPLIES"><i class="fa fa-trash-o" aria-hidden="true"> &nbsp;Delete</a></span> &nbsp; &nbsp;';
		$statusReportButton = '<a href="#" onclick="return false;" onmousedown="reportStatus(\''.$statusid.'\');" title="REPORT THIS STATUS"><i class="fa fa-flag" aria-hidden="true"></i> &nbsp;Report</a>';
	}
	//Option Btn Code
	$moreOptionBtn = '';
	if($statusReportButton != '' || $statusDeleteButton != ''){
		$moreOptionBtn .= '<div class="dropdown pull-right moreOptionBtn">';
		$moreOptionBtn .= '<button class="btn btn-default dropdown-toggle left_side_panel" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true"><i class="fa fa-ellipsis-v"></i></button>';
		$moreOptionBtn .= '<ul class="dropdown-menu ">';
		if($statusDeleteButton != '') {
			$moreOptionBtn .= '<li>'.$statusDeleteButton.'</li>';		
		}
		$moreOptionBtn .= '<li>'.$statusReportButton.'</li>';	
		//$moreOptionBtn .= '<a href="#" onclick="return false;" onmousedown="deleteStatus('70','status_70');" title="DELETE THIS STATUS AND ITS REPLIES"><i class="fa fa-trash-o" aria-hidden="true"></i>&nbsp; Delete</a>';
		$moreOptionBtn .= '</ul>';
		$moreOptionBtn .= '</div>';
	}
	// GATHER UP ANY STATUS REPLIES
	$status_replies = "";
	$query_replies = mysqli_query($db_conx, 
	   "SELECT s.*,u.username,u.avatar  
		FROM status s,users u 
		WHERE 
			osid='$statusid' 
			AND 
			type='b'
			AND
			s.author_id=u.id 
		ORDER BY postdate DESC
		LIMIT 5
	");
	$replynumrows = mysqli_num_rows($query_replies);
	$query_total_replies = mysqli_query($db_conx, 
		   "SELECT COUNT(s.id)
			FROM status s
			WHERE 
				osid='$statusid' 
				AND 
				type='b'
	");
	$reply_total_num_rows = mysqli_fetch_row($query_total_replies);	
	$reply_total_nums = $reply_total_num_rows[0];
    if($replynumrows > 0){
        while ($row2 = mysqli_fetch_array($query_replies, MYSQLI_ASSOC)) {
			$statusreplyid = $row2["id"];
			$replyauthor = $row2["author_id"];
			$replay_author_name = $row2["username"];
			$replay_author_avatar = $row2["avatar"];
			$replydata = $row2["data"];
			$replydata = nl2br($replydata);
			//$replypostdate = $row2["postdate"];
			$replypostdate = date('M d, Y', strtotime($row2["postdate"]));
			$replydata = str_replace("&amp;","&",$replydata);
			$replydata = stripslashes($replydata);
			$replyDeleteButton = '';
			if($replyauthor == $log_id || $account_name == $log_id ){
				$replyDeleteButton = 
					'<span id="srdb_'.$statusreplyid.'">
						<a href="#" onclick="return false;" onmousedown="deleteReply(\''.$statusreplyid.'\',\'reply_'.$statusreplyid.'\');" title="DELETE THIS COMMENT">Delete</a>
					</span>';
			}
			$reply_author_profile_pic = '';
		    $reply_author_profile_pic = '<img src="user/'.dir_encrypt($replay_author_name).'/'.$replay_author_avatar.'" alt="'.$replay_author_name.'">';
		    if($replay_author_avatar == NULL){
		        $reply_author_profile_pic = '<img src="images/avatardefault.jpg" alt="'.$replay_author_name.'">';
		    }   
			$status_replies .= 
				'<div id="reply_'.$statusreplyid.'" class="reply_boxes row">
					<div class="col-xs-2 col-sm-2 col-md-1">'.
						$reply_author_profile_pic.'
					</div>
					<div class="col-xs-10 col-sm-10 col-md-11">	
						<h5><a href="user.php?u='.$replay_author_name.'">'.$replay_author_name.'</a></h5>'.
						'<p class="replaydata">'.$replydata.'<p class="reply_meta">'.
						'<span>'.$replypostdate.' &nbsp;'.
						$replyDeleteButton.
						'</span>'.						
					'</div>
				</div>';
        }
    	if($reply_total_nums > $replynumrows){
    		$status_replies .= '<div class="load-more-comments"><a onclick="loadMoreComments(event,this,2);" data-loaded="'.$replynumrows.'" data-trep="'.$reply_total_nums.'" data-std="'.$statusid.'">view more</a></div>';
    	}
    }
    $author_profile_pic = '<img src="user/'.dir_encrypt($author_name).'/'.$author_avatar.'" alt="'.$author_name.'">';
    if($author_avatar == NULL){
        $author_profile_pic = '<img src="images/avatardefault.jpg" alt="'.$author_name.'">';
    }   
	$oneStatusBlock .= 
		'<div class="status_boxes">
			<div>'.
				'<span>'.
				$author_profile_pic.
				'</span>
				<p>
				<a class="authorname" href="user.php?u='.$author_name.'">'.$author_name.'</a> <br><span class="date">'.
				$postdate.'</span></p>'.$moreOptionBtn.'<div class="clear"></div><div class="data">'.
				$data.$statusLikeButton.'</div>
			</div>'.
		'</div>';
	if($isFriend == true || $log_id == $user_id){
		$oneStatusBlock .= '<div class="commentBox" id="commentbox_'.$statusid.'">';
		$oneStatusBlock .= '<div class="likesANDcomments">';		
		$oneStatusBlock .= '<p><a id="likes_'.$statusid.'">'.$total_likes.' likes</a> . <a>'.$reply_total_nums.' comments</a></p>';
		$oneStatusBlock .= '</div>';	
		if($isFriend == true || $log_id=$author){	
		$oneStatusBlock .= '<div class="logUserCommentBox">';
	    $oneStatusBlock .= '<div class="hidden-xs col-sm-2 col-md-1 text-center">';
	    $oneStatusBlock .= '<span>'.$profile_pic.'</span>';
	    $oneStatusBlock .= '</div>';
	    $oneStatusBlock .= '<div class="input-group col-xs-12 col-sm-10 col-md-11">';
	    $oneStatusBlock .= '<input type="text" id="replytext_'.$statusid.'" class="form-control replytext" onkeyup="statusMax(this,500)" placeholder="write a comment here"/>';
	    $oneStatusBlock .= '<span class="input-group-btn"><button class="btn btn-secondary" id="replyBtn_'.$statusid.'" onclick="replyToStatus('.$statusid.',\''.$log_id.'\',\'replytext_'.$statusid.'\',this)"><i class="fa fa-paper-plane" aria-hidden="true"></i></button></span>';
	    $oneStatusBlock .= '</div>';
	    $oneStatusBlock .= '</div>';
		}
		$oneStatusBlock .= '<div class="clear"></div>';
	    $oneStatusBlock .= $status_replies;
		$oneStatusBlock .= '</div>';
	} else {
		$oneStatusBlock .= '<div class="commentBox" id="commentbox_'.$statusid.'">';
		$oneStatusBlock .= '<div class="likesANDcomments">';		
		$oneStatusBlock .= '<p><a id="likes_'.$statusid.'">'.$total_likes.' likes</a> . <a>'.$replynumrows.' comments</a></p>';
		$oneStatusBlock .= '</div>';		
		$oneStatusBlock .= '<div class="clear"></div>';
	    $oneStatusBlock .= $status_replies;
		$oneStatusBlock .= '</div>';
	}
	$statuslist .= '<div id="status_'.$statusid.'">'.$oneStatusBlock.'</div>';
	$oneStatusBlock = ''; 
}


?>

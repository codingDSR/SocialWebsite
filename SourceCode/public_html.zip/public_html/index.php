<?php 
include_once("php_includes/check_login_status.php");
// Make sure the user is logged in and sanitize the session
if(isset($_SESSION['username'])){
	header("location: feeds.php");
    exit();	
} else {
    header("location: login.php");
    exit();	
}
?>
<html> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"> 
<title>Under Construction</title> 
</head> 
<body> 
<br><br><br><br><br><br><br> 
<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center"> 
   <tr> 
      <td align="center"> 
      <img src="error.png" border="0"> 
      <h1 style="margin:0;padding:0;font-family: trebuchet ms;">This Website is Under Construction.
      <br><small style="color: #888;" align="center">Come Back Soon.</small> 
      </h1> 
      </td> 
      </tr> 
    </table> 
  </body> 
</html> 
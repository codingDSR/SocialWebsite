<?php
include_once("php_includes/check_login_status.php");
if(isset($_SESSION['username'])){
} else {
    header("location: login.php");
    exit();	
}
if(isset($_GET["pid"])){
	require_once('php_includes/dir_hash.php');
	$pid = preg_replace('#[^0-9]#i', '', note_decrypt($_GET['pid']));
	require_once('php_includes/libs_link.php');
	require_once('view_components/template_logged_user_avatar.php');
	require_once('php_includes/process_post_data.php');
} else {
    //page not exist page..
    header("location: login.php");
    exit();
}
$user_id = $log_id;
//require('./php_includes/db_conx.php');
//$status_ui = "";
$statuslist = "";
$isFriend = false;
// if($isOwner == "yes"){
// 	$status_ui = '<textarea class="form-control" id="statustext" onkeyup="statusMax(this,250)" placeholder="What&#39;s new with you '.$u.'?"></textarea>';
// 	$status_ui .= '<button id="statusBtn" onclick="postToStatus(\'status_post\',\'a\',\''.$u.'\',\'statustext\')">Post</button>';
// } else if($isFriend == true && $log_username != $u){
// 	//$status_ui = '<textarea class="form-control" id="statustext" onkeyup="statusMax(this,250)" placeholder="Hi '.$log_username.', say something to '.$u.'"></textarea>';
// 	//$status_ui .= '<button id="statusBtn" onclick="postToStatus(\'status_post\',\'c\',\''.$u.'\',\'statustext\')">Post</button>';
// }

// if($isOwner == "yes"){
	// $status_ui = '<textarea class="form-control" id="statustext" onkeyup="statusMax(this,250)" placeholder="What&#39;s new with you '.$u.'?"></textarea>';
	// $status_ui .= '<div id="uploadDisplay_SP"></div>';
	// $status_ui .= '<div id="btns_SP" class="">';
	// 	$status_ui .= '<button class="btn button-lg button-primary" id="statusBtn" onclick="postToStatus(\'status_post\',\'a\',\''.$u.'\',\'statustext\')">Post</button>';
	// 	$status_ui .= '<button id="triggerBtn_SP" class="btn button-lg button-primary triggerBtn" onclick="triggerUpload(event, \'fu_SP\')" >Attach Photo</button>';
	// 	$status_ui .= '<input id="public_private_post" data-toggle="toggle" data-on="Private" data-off="Public" type="checkbox" data-toggle="toggle" data-width="100">';
	// $status_ui .= '</div>';
	// $status_ui .= '<div id="standardUpload" class="hiddenStuff">';
	// 	$status_ui .= '<form id="image_SP" enctype="multipart/form-data" method="post">';
	// 	$status_ui .= '<input type="file" name="FileUpload" id="fu_SP" onchange="doUpload(\'fu_SP\')"/>';
	// 	$status_ui .= '</form>';
	// $status_ui .= '</div>';
// } else if($isFriend == true && $log_username != $u){
	// $status_ui = '<textarea id="statustext" onkeyup="statusMax(this,250)" onfocus="showBtnDiv()" placeholder="Hi '.$log_username.', say something to '.$u.'"></textarea>';
	// $status_ui .= '<div id="uploadDisplay_SP"></div>';
	// $status_ui .= '<div id="btns_SP" class="hiddenStuff">';
	// 	$status_ui .= '<button id="statusBtn" onclick="postToStatus('status_post','c',''.$u.'','statustext')">Post</button>';
	// 	$status_ui .= '<img src="images/camera.JPG" id="triggerBtn_SP" class="triggerBtn" onclick="triggerUpload(event, 'fu_SP')" width="137" height="22" title="Upload A Photo" />';
	// $status_ui .= '</div>';
	// $status_ui .= '<div id="standardUpload" class="hiddenStuff">';
	// 	$status_ui .= '<form id="image_SP" enctype="multipart/form-data" method="post">';
	// 	$status_ui .= '<input type="file" name="FileUpload" id="fu_SP" onchange="doUpload('fu_SP')"/>';
	// 	$status_ui .= '</form>';
	// $status_ui .= '</div>';
// }

?><?php

// $res = mysqli_query($db_conx,"SELECT id FROM users WHERE username='$u' LIMIT 1");
// if(mysqli_num_rows($res)>0){
// 	$row = mysqli_fetch_array($res);
// 	$user_id = $row["id"];
// } else {
// 	echo "No Such User";
// 	die();
// }

// $user_id = $profile_id;
// $photos_gallery = '';
// $total_photos = '0';

// $sql = "SELECT COUNT(id) as counts FROM status WHERE account_id='$user_id' AND type NOT IN ('b','d') AND postimage IS NOT NULL";
// $query = mysqli_query($db_conx, $sql);
// $row = mysqli_fetch_row($query);
// $total_photos = $row[0];


// $sql = "SELECT postimage FROM status 
// 			WHERE 
// 				account_id='$user_id' 
// 				AND 
// 				type NOT IN ('b','d')
// 				AND 
// 				postimage IS NOT NULL
// 			ORDER BY postdate DESC 
// 			LIMIT 20";
// $query = mysqli_query($db_conx, $sql);
// while ($row = mysqli_fetch_array($query, MYSQLI_ASSOC)) {
// 	$photos_gallery .= '<li><img class="img-responsive" src="permUploads/'.$row["postimage"].'"/></li>';
// }

// $total_rows_sql="SELECT count(s.id)
// 				FROM status s
// 				WHERE 
// 					account_id='$user_id' 
// 					AND 
// 					type NOT IN ('b','d')
// ";
// $total_rows_query = mysqli_query($db_conx, $total_rows_sql);
// $total_status_row = mysqli_fetch_row($total_rows_query);
// $total_status_nums = $total_status_row[0];


$oneStatusBlock = ''; 
// if($log_username == $u) {
// 	$sql = "SELECT s.*,u.username,u.avatar 
// 			FROM status s,users u 
// 			WHERE 
// 				account_id='$user_id' 
// 				AND 
// 				type NOT IN ('b')
// 				AND
// 				s.author_id=u.id 
// 			ORDER BY postdate DESC 
// 			LIMIT 20";
// } else {
	$sql = "SELECT s.*,u.username,u.avatar 
			FROM status s,users u 
			WHERE 
				type NOT IN ('b','d')
				AND
				s.author_id=u.id 
				AND
				s.id=$pid
			LIMIT 1";	
//}


$query = mysqli_query($db_conx, $sql);
$statusnumrows = mysqli_num_rows($query);
if($statusnumrows < 1){
	$statuslist = '<div style="padding:10px;"><h3>Something went wrong.<h3><p style="font-size:16px;">The post you want to view may be removed or broken.</p><a style="font-size:16px;text-decoration:none;" href="#" onclick="return false;" onmousedown="window.history.back();">Back</a></div>';
} else {
while ($row = mysqli_fetch_array($query, MYSQLI_ASSOC)) {
	$statusid = $row["id"];
	$account_name = $row["account_id"];
	$author = $row["author_id"];
	$author_name = $row["username"];
	$author_avatar = $row["avatar"];
	//$postdate = date_format($row["postdate"],"Y/m/d");
	$postdate = date('M d, Y', strtotime($row["postdate"]));
	$data = $row["data"];
	$data = nl2br($data);
	$data = str_replace("&amp;","&",$data);
	$data = makeClickableLinks(convertYoutube(stripslashes($data)));


	//checking friend
	if($author==$log_id){
		$isFriend = true;
	} else 	if($author!=$log_id && $user_ok == true){
		$friend_check = "SELECT id FROM friends WHERE user1_id='$log_id' AND user2_id='$author' AND accepted='1' OR user1_id='$author' AND user2_id='$log_id' AND accepted='1' LIMIT 1";
		if(mysqli_num_rows(mysqli_query($db_conx, $friend_check)) > 0){
	        $isFriend = true;
	    }
	} 
	// if($isFriend == false ){
	// 	$statuslist = 'Something went wrong...';
	// }


	// Status Likes Code
	$likedStatus = '';
	$likers_profile_pic = '';
	$total_likes = '';
	$likers_tray_html = '';
	$row = mysqli_fetch_row(mysqli_query($db_conx, "SELECT COUNT(id) FROM likes WHERE status_id='$statusid'"));
	$total_likes = intval($row[0]);	

	if($total_likes > 0) {
		$Likers_tray_sql = "SELECT u.avatar,u.username FROM likes l,users u WHERE status_id='$statusid' AND l.liker_id=u.id  ORDER BY l.id DESC LIMIT 5";		
		if($total_likes > 5) {
			$likers_tray_html .= '<a class="moreLikers">+'.($total_likes-5).'</a>'; 
		}
		$Likers_tray_query = mysqli_query($db_conx, $Likers_tray_sql);
		while($r=mysqli_fetch_array($Likers_tray_query)){ 
			if($r["avatar"] == NULL){
				$likers_tray_html .='<img onclick="window.location.assign(\'user.php?u='.$r["username"].'\')" src="images/avatardefault.png"/>';
			} else {
				$likers_tray_html .='<img onclick="window.location.assign(\'user.php?u='.$r["username"].'\')" src="user/'.dir_encrypt($r["username"]).'/'.$r["avatar"].'"/>';
			}		
		}
	}

	$is_liked_post_query = "SELECT id FROM likes WHERE liker_id='$log_id' AND status_id='$statusid' LIMIT 1";
	if(mysqli_num_rows(mysqli_query($db_conx,$is_liked_post_query)) > 0) {
		$likedStatus = true;
	}
	if($likedStatus == true){
		//$total_likes_query = "SELECT count(id) FROM likes WHERE status_id='$statusid'";
		// while($lrow = mysqli_fetch_array(mysqli_query($db_conx,$total_likes_query))){
		// 	$total_likes = $lrow[0];
		// }
	}
	// if($total_likes > 1) {
	// 	$likers_query = "SELECT u.username,u.avatar FROM likes l,users u WHERE l.status_id='$statusid' AND l.user_id=u.id ORDER BY id DESC LIMIT 5";
	// 	while($lkrow = mysqli_fetch_array(mysqli_query($db_conx,$likers_query))){
	// 		$liker = $lkrow["username"];
	// 		$liker_avatar = $lkrow["avatar"];
	// 	    if($liker_avatar == NULL){
	// 	        $likers_profile_pic .= '<img src="images/avatardefault.jpg" alt="'.$liker.'">';
	// 	    } else {
	// 	    	$likers_profile_pic .= '<img src="user/'.dir_encrypt($liker).'/'.$liker_avatar.'" alt="'.$liker.'">';
	// 	    }			
	// 	}
	// }
	$statusLikeButton = '';	
	if($log_username != "" && $author != $log_username && $account_name != $log_username){
		$statusLikeButton .= '<div class="likebtn row">';
		$statusLikeButton .= '<div class="col-xs-2 col-sm-2 col-md-2">';
		if($likedStatus == true){
			$statusLikeButton .= '<button data-lkd="_y_" data-std="'.$statusid.'" onclick="likeOrUnlikeStatus(\''.$statusid.'\',this);" class="btn liked">+1</button>';
		} else {
			$statusLikeButton .= '<button data-lkd="_n_" data-std="'.$statusid.'" onclick="likeOrUnlikeStatus(\''.$statusid.'\',this);" class="btn">+1</button>';
		}
		$statusLikeButton .= '</div>';
		$statusLikeButton .= '<div class="col-xs-10 col-sm-10 col-md-10" id="likers_tray_'.$statusid.'">';
		$statusLikeButton .= $likers_tray_html;
		//$statusLikeButton .= '<a class="moreLikers">+102</a>';
		//$statusLikeButton .= '<img src="user/fVjtXEV0MPvfZrbG0nb2IvjTaohdjFZe4MNhtgkdQp02/-328886068.jpg"/><img src="images/avatardefault.jpg"/>';
		$statusLikeButton .= '</div>';
		$statusLikeButton .= '</div>';
	}


	// Delete Btn Code
	$statusDeleteButton = '';
	if($author == $log_id || $account_name == $log_id ){
		//$statusDeleteButton = '<span id="sdb_'.$statusid.'"><a href="#" onclick="return false;" onmousedown="deleteStatus(\''.$statusid.'\',\'status_'.$statusid.'\');" title="DELETE THIS STATUS AND ITS REPLIES"><i class="fa fa-trash-o" aria-hidden="true"> &nbsp;Delete</a></span> &nbsp; &nbsp;';
		$statusDeleteButton = '<a href="#" onclick="return false;" onmousedown="deleteStatus(\''.$statusid.'\',\'status_'.$statusid.'\');" title="DELETE THIS STATUS AND ITS REPLIES"><i class="fa fa-trash-o" aria-hidden="true"></i> &nbsp;Delete</a>';
	}
	
	// Report Btn Code
	$statusReportButton = '';
	if($log_username != "" && $author != $log_id && $account_name != $log_username){
		//$statusDeleteButton = '<span id="sdb_'.$statusid.'"><a href="#" onclick="return false;" onmousedown="deleteStatus(\''.$statusid.'\',\'status_'.$statusid.'\');" title="DELETE THIS STATUS AND ITS REPLIES"><i class="fa fa-trash-o" aria-hidden="true"> &nbsp;Delete</a></span> &nbsp; &nbsp;';
		$statusReportButton = '<a href="#" onclick="return false;" onmousedown="reportStatus(\''.$statusid.'\');" title="REPORT THIS STATUS"><i class="fa fa-flag" aria-hidden="true"></i> &nbsp;Report</a>';
	}
	//Option Btn Code
	$moreOptionBtn = '';
	if($statusReportButton != '' || $statusDeleteButton != ''){
		$moreOptionBtn .= '<div class="dropdown pull-right moreOptionBtn">';
		$moreOptionBtn .= '<button class="btn btn-default dropdown-toggle left_side_panel" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true"><i class="fa fa-ellipsis-v"></i></button>';
		$moreOptionBtn .= '<ul class="dropdown-menu ">';
		if($statusDeleteButton != '') {
			$moreOptionBtn .= '<li>'.$statusDeleteButton.'</li>';		
		}
		$moreOptionBtn .= '<li>'.$statusReportButton.'</li>';	
		//$moreOptionBtn .= '<a href="#" onclick="return false;" onmousedown="deleteStatus('70','status_70');" title="DELETE THIS STATUS AND ITS REPLIES"><i class="fa fa-trash-o" aria-hidden="true"></i>&nbsp; Delete</a>';
		$moreOptionBtn .= '</ul>';
		$moreOptionBtn .= '</div>';
	}
	// GATHER UP ANY STATUS REPLIES
	$status_replies = "";
	$query_replies = mysqli_query($db_conx, 
	   "SELECT s.*,u.username,u.avatar  
		FROM status s,users u 
		WHERE 
			osid='$statusid' 
			AND 
			type='b'
			AND
			s.author_id=u.id 
		ORDER BY postdate DESC
		LIMIT 5
	");
	$replynumrows = mysqli_num_rows($query_replies);
	$query_total_replies = mysqli_query($db_conx, 
		   "SELECT COUNT(s.id)
			FROM status s
			WHERE 
				osid='$statusid' 
				AND 
				type='b'
	");
	$reply_total_num_rows = mysqli_fetch_row($query_total_replies);	
	$reply_total_nums = $reply_total_num_rows[0];
    if($replynumrows > 0){
        while ($row2 = mysqli_fetch_array($query_replies, MYSQLI_ASSOC)) {
			$statusreplyid = $row2["id"];
			$replyauthor = $row2["author_id"];
			$replay_author_name = $row2["username"];
			$replay_author_avatar = $row2["avatar"];
			$replydata = $row2["data"];
			$replydata = nl2br($replydata);
			//$replypostdate = $row2["postdate"];
			$replypostdate = date('M d, Y', strtotime($row2["postdate"]));
			$replydata = str_replace("&amp;","&",$replydata);
			$replydata = stripslashes($replydata);
			$replyDeleteButton = '';
			if($replyauthor == $log_id || $account_name == $log_id ){
				$replyDeleteButton = 
					'<span id="srdb_'.$statusreplyid.'">
						<a href="#" onclick="return false;" onmousedown="deleteReply(\''.$statusreplyid.'\',\'reply_'.$statusreplyid.'\');" title="DELETE THIS COMMENT">Delete</a>
					</span>';
			}
			$reply_author_profile_pic = '';
		    $reply_author_profile_pic = '<img src="user/'.dir_encrypt($replay_author_name).'/'.$replay_author_avatar.'" alt="'.$replay_author_name.'">';
		    if($replay_author_avatar == NULL){
		        $reply_author_profile_pic = '<img src="images/avatardefault.jpg" alt="'.$replay_author_name.'">';
		    }   
			$status_replies .= 
				'<div id="reply_'.$statusreplyid.'" class="reply_boxes row">
					<div class="col-xs-2 col-sm-2 col-md-1">'.
						$reply_author_profile_pic.'
					</div>
					<div class="col-xs-10 col-sm-10 col-md-11">	
						<h5><a href="user.php?u='.$replay_author_name.'">'.$replay_author_name.'</a></h5>'.
						'<p class="replaydata">'.$replydata.'<p class="reply_meta">'.
						'<span>'.$replypostdate.' &nbsp;'.
						$replyDeleteButton.
						'</span>'.						
					'</div>
				</div>';
        }
    	if($reply_total_nums > $replynumrows){
    		$status_replies .= '<div class="load-more-comments"><a onclick="loadMoreComments(event,this,2);" data-loaded="'.$replynumrows.'" data-trep="'.$reply_total_nums.'" data-std="'.$statusid.'">view more</a></div>';
    	}
    }
    $author_profile_pic = '<img src="user/'.dir_encrypt($author_name).'/'.$author_avatar.'" alt="'.$author_name.'">';
    if($author_avatar == NULL){
        $author_profile_pic = '<img src="images/avatardefault.jpg" alt="'.$author_name.'">';
    }   
	$oneStatusBlock .= 
		'<div class="status_boxes">
			<div>'.
				'<span>'.
				$author_profile_pic.
				'</span>
				<p>
				<a class="authorname" href="user.php?u='.$author_name.'">'.$author_name.'</a> <br><span class="date">'.
				$postdate.'</span></p>'.$moreOptionBtn.'<div class="clear"></div><div class="data">'.
				$data.$statusLikeButton.'</div>
			</div>'.
		'</div>';
	if($isFriend == true || $log_id == $user_id){
		$oneStatusBlock .= '<div class="commentBox" id="commentbox_'.$statusid.'">';
		$oneStatusBlock .= '<div class="likesANDcomments">';		
		$oneStatusBlock .= '<p><a id="likes_'.$statusid.'">'.$total_likes.' likes</a> . <a>'.$reply_total_nums.' comments</a></p>';
		$oneStatusBlock .= '</div>';		
		$oneStatusBlock .= '<div class="logUserCommentBox">';
	    $oneStatusBlock .= '<div class="hidden-xs col-sm-2 col-md-1 text-center">';
	    $oneStatusBlock .= '<span>'.$profile_pic.'</span>';
	    $oneStatusBlock .= '</div>';
	    $oneStatusBlock .= '<div class="input-group col-xs-12 col-sm-10 col-md-11">';
	    $oneStatusBlock .= '<input type="text" id="replytext_'.$statusid.'" class="form-control replytext" onkeyup="statusMax(this,250)" placeholder="write a comment here"/>';
	    $oneStatusBlock .= '<span class="input-group-btn"><button class="btn btn-secondary" id="replyBtn_'.$statusid.'" onclick="replyToStatus('.$statusid.',\''.$log_id.'\',\'replytext_'.$statusid.'\',this)"><i class="fa fa-paper-plane" aria-hidden="true"></i></button></span>';
	    $oneStatusBlock .= '</div>';
	    $oneStatusBlock .= '</div>';
		$oneStatusBlock .= '<div class="clear"></div>';
	    $oneStatusBlock .= $status_replies;
		$oneStatusBlock .= '</div>';
	} else {
		$oneStatusBlock .= '<div class="commentBox" id="commentbox_'.$statusid.'">';
		$oneStatusBlock .= '<div class="likesANDcomments">';		
		$oneStatusBlock .= '<p><a id="likes_'.$statusid.'">'.$total_likes.' likes</a> . <a>'.$replynumrows.' comments</a></p>';
		$oneStatusBlock .= '</div>';		
		$oneStatusBlock .= '<div class="clear"></div>';
	    $oneStatusBlock .= $status_replies;
		$oneStatusBlock .= '</div>';
	}
	$statuslist .= '<div id="status_'.$statusid.'">'.$oneStatusBlock.'</div>';
	$oneStatusBlock = ''; 
}

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta name="description" content="">
    <meta name="author" content="">
	<style>
		@import url('https://fonts.googleapis.com/css?family=Dosis:400,600|Open+Sans:300,400,600|Roboto:300,400,500');
	</style>
	<link rel="icon" href="favicon.ico" type="image/x-icon">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
	<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
	<title>User Posts</title>
	<script src="js/main.js"></script>
	<script src="js/ajax.js"></script>	
	<script>
const checkNetConnectivity =function(){
	if(typeof navigator.onLine != undefined && typeof navigator.onLine == "boolean"){
		return !(navigator.onLine);
	} else {
		return false;
	}
}		
const noConnectionStatusDisplay = function(){
	_('Notice-NoInternet').click();
	return ;	
}	
const unexptedErrorMessage = function(){
	alert('unexpected error occurred. Refreshing page...');
	setTimeout(function(){
		window.location.assign(window.location.href);
	},2500);
};
const trim = function(txt) {
	return txt.replace(/^\s+|\s+$/g,"");
}	
const hasClass = function( elem, cls ) {
     return (" " + elem.className + " " ).indexOf( " "+cls+" " ) > -1;
}
function statusMax(field, maxlimit) {
	if (field.value.length > maxlimit){
		alert(maxlimit+" maximum character limit reached");
		field.value = field.value.substring(0, maxlimit);
	}
}
const likeOrUnlikeStatus = function(std,ref){
	if(checkNetConnectivity()){
		noConnectionStatusDisplay();
		return ;
	}	
	//ref.disabled = true;
	var action = "";
	ref.style.background = "#00acee";
	ref.innerHTML = "<img src=\"images/loader_basic.gif\" width=\"22px\" height=\"22px\">";
	if(parseInt(ref.getAttribute('data-std')) == parseInt(std)){
		std = parseInt(std);
	} else {
		unexptedErrorMessage();
	}
	if(ref.getAttribute('data-lkd') == '_y_' && hasClass(ref,'liked')) {
		action = "unlike_status";
	} else if(ref.getAttribute('data-lkd') == '_n_'){
		action = "like_status";
	} else {
		return ;
	}
	var ajax = ajaxObj("POST", "php_parsers/likes_system.php");
	ajax.onreadystatechange = function() {
		if(ajaxReturn(ajax) == true) {
			var likesData = JSON.parse(ajax.responseText);
			//console.log(likesData);
			//console.log(ajax.responseText);
			if(likesData.status == 'ok'){
				_('likes_'+std).innerHTML = likesData.total_likes+" likes";
				ref.innerHTML = '+1';
				ref.disabled = false;
				if(action =='like_status'){
					ref.classList.add('liked');
					ref.setAttribute('data-lkd','_y_');
				} else {
					ref.style.background = "transparent";
					ref.classList.remove('liked');
					ref.setAttribute('data-lkd','_n_');
				} 
				var likers_html = '';
				if(parseInt(likesData.total_likes) < 1){
					_('likers_tray_'+std).innerHTML = '';
					return ;
				}
				if(likesData.total_likes > 5){
					likers_html += '<a class="moreLikers">+'+(parseInt(likesData.total_likes)-5)+'</a>';
				} 
				for(var i=0;i<likesData.likers_avatar[0].length;i++){
					likers_html += '<img src="'+likesData.likers_avatar[0][i]+'"/>';
				}
				_('likers_tray_'+std).innerHTML = likers_html;

				//_(statusbox).style.display = 'none';
				//_("replytext_"+statusid).style.display = 'none';
				//_("replyBtn_"+statusid).style.display = 'none';
			} else {
				alert(likesData.error);
			}
		}
	}
	ajax.send("action="+action+"&statusid="+std);
}
function reportStatus(std){
	if(checkNetConnectivity()){
		noConnectionStatusDisplay();
		return ;
	}		
	std = parseInt(std);
	if(typeof std != "number") {
		return;
	}
	var ajax = ajaxObj("POST", "php_parsers/report_system.php");
	ajax.onreadystatechange = function() {
		if(ajaxReturn(ajax) == true) {
			if(ajax.responseText == "reported"){
				setTimeout(function(){
					_("status_"+std).style.display = "none";
					_("status_"+std).innerHTML = "";	
				},5000);
				_("status_"+std).style.padding = "6px";
				_("status_"+std).style.background = "#fbfbfb";
				_("status_"+std).style.border = "1px solid #ddd";
				_("status_"+std).innerHTML = '<center><h3>Reported!</h3><p>We will validate post soon.<div style="height:5px;"></div></p></center>';
			} else {
				unexptedErrorMessage();
				//alert(ajax.responseText);
			}
		}
	}
	ajax.send("action=report_status&statusid="+std);
}
function deleteStatus(statusid,statusbox){
	if(checkNetConnectivity()){
		noConnectionStatusDisplay();
		return ;
	}		
	var conf = confirm("Press OK to confirm deletion of this status and its replies");
	if(conf != true){
		return false;
	}
	var ajax = ajaxObj("POST", "php_parsers/status_system.php");
	ajax.onreadystatechange = function() {
		if(ajaxReturn(ajax) == true) {
			if(ajax.responseText == "delete_ok"){
				_(statusbox).style.display = 'none';
				_("replytext_"+statusid).style.display = 'none';
				_("replyBtn_"+statusid).style.display = 'none';
			} else {
				unexptedErrorMessage();
				//alert(ajax.responseText);
			}
		}
	}
	ajax.send("action=delete_status&statusid="+statusid);
}
function replyToStatus(sid,user,ta,btn){
	if(checkNetConnectivity()){
		noConnectionStatusDisplay();
		return ;
	}		
	var data = trim(_(ta).value);
	if(data == ""){
		//alert("Type something first weenis");
		return false;
	}
	_("replyBtn_"+sid).disabled = true;
	var ajax = ajaxObj("POST", "php_parsers/status_system.php");
	ajax.onreadystatechange = function() {
		if(ajaxReturn(ajax) == true) {
			var datArray = ajax.responseText.split("|");
			if(datArray[0] == "reply_ok"){
				var rid = datArray[1];
				data = data.replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/\n/g,"<br />").replace(/\r/g,"<br />");
				_("commentbox_"+sid).innerHTML += '<div id="reply_'+rid+'" class="reply_boxes row"><div><b>Reply by you just now: </b><span id="srdb_'+rid+'"><a href="#" onclick="return false;" onmousedown="deleteReply(\''+rid+'\',\'reply_'+rid+'\');" title="DELETE THIS COMMENT">Delete</a></span><br />'+data+'</div></div>';
				_("replyBtn_"+sid).disabled = false;
				_(ta).value = "";
			} else {
				unexptedErrorMessage();
				//alert(ajax.responseText);
			}
		}
	}
	ajax.send("action=status_reply&sid="+sid+"&user="+user+"&data="+data);
}
function deleteReply(replyid,replybox){
	if(checkNetConnectivity()){
		noConnectionStatusDisplay();
		return ;
	}		
	var conf = confirm("Press OK to confirm deletion of this reply");
	if(conf != true){
		return false;
	}
	var ajax = ajaxObj("POST", "php_parsers/status_system.php");
	ajax.onreadystatechange = function() {
		if(ajaxReturn(ajax) == true) {
			if(ajax.responseText == "delete_ok"){
				_(replybox).style.display = 'none';
			} else {
				unexptedErrorMessage();
				//alert(ajax.responseText);
			}
		}
	}
	ajax.send("action=delete_reply&replyid="+replyid);
}
var isLoadingNewStatusComments = false;
const loadMoreComments = function(e,ref,tym){
		if(checkNetConnectivity()){
			noConnectionStatusDisplay();
			return ;
		}		
		if(typeof tym == "number" && tym>0){
			ref = $(ref);
		} 
		e.preventDefault();
		if(isLoadingNewStatusComments == false){
			isLoadingNewStatusComments = true;
			ref.parent().html('<div class="loading-new-status" style="text-align:center;"><img src="images/loading-arrow.gif" style="width: 17px;height: 17px;"/> Loading...</div>');
			var totalComments = parseInt(ref.attr('data-trep'));
			var loadedComments = parseInt(ref.attr('data-loaded'));
			var statusid = parseInt(ref.attr('data-std'));

			if(isLoadingNewStatusComments){
					var ajax = ajaxObj("POST", "php_parsers/get_more_status_comments_system.php");
					ajax.onreadystatechange = function() {
						if(ajaxReturn(ajax) == true) {
							if(ajax.responseText.length > 50){
								isLoadingNewStatusComments = false;
								$('#commentbox_'+statusid+' .load-more-comments').html('').hide();
								ref.parent().html('').hide();
								_('commentbox_'+statusid).innerHTML += ajax.responseText; 
							}
						}
					}
					ajax.send("action=load_status_comments&u=<?php echo $log_username;?>&uid=<?php echo $log_id;?>&statusid="+statusid+"&loadedComments="+loadedComments);
			}
		} else {
			return ;
		}				
}
	</script>
</head>
<body>
	<?php include_once("view_components/template_pageTop.php"); ?>
        <div id="page-content-wrapper">
        	<div style="margin-top:40px;">
        	</div>			
            <div class="container-fluid xyz row">
            	<div class="row">
					<div class="col-xs-12 col-sm-12 col-md-8" id="profile-posts-tab">
						<div id="">
						  <?php echo $statuslist; ?>
						</div>	
					</div>            		
					<div class="col-xs-12 col-sm-12 col-md-4"></div>
            	</div>
            </div>
        </div>
    </div>
	<?php include_once("view_components/template_pageBottom.php"); ?>
	<script src="js/sidebar_menu.js"></script>	
</body>
</html>
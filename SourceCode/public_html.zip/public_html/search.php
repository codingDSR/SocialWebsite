<?php
include_once("php_includes/check_login_status.php");
// If the page requestor is not logged in, usher them away
if($user_ok != true || $log_username == ""){
	header("location: login.php");
    exit();
} else {
	require_once('php_includes/dir_hash.php');
}
$popular_users = '';
$sql = "SELECT avatar,username FROM users where activated ='1' LIMIT 20";
$res = mysqli_query($db_conx,$sql);
if(mysqli_num_rows($res)>0){
	while($row=mysqli_fetch_array($res)){
		$username = $row["username"];
		$avatar = $row["avatar"];

		$popular_users .= '<div class="follower">';
		if($avatar == null){
			$popular_users .= '<img class="friendpics"src="images/avatardefault.png" alt="'.$username.'"/>';
		} else {
			$popular_users .= '<img class="friendpics"src="user/'.dir_encrypt($username).'/'.$avatar.'" alt="'.$username.'"/>';
		}
		$popular_users .= '<div class="body">';
		$popular_users .= '<div class="follower-controls">';
		$popular_users .= '<a href="user.php?u='.$username.'" class="btn btn-sm btn-outline">View Profile</a>';
		$popular_users .= '</div>';
		$popular_users .= '<a href="user.php?u='.$username.'" class="follower-name">'.$username.'</a><br></div></div>';


	}
} else {

}


?>


<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta name="description" content="">
    <meta name="author" content="">
	<style>
		@import url('https://fonts.googleapis.com/css?family=Dosis:400,600|Open+Sans:300,400,600|Roboto:300,400,500');
	</style>
	<link rel="icon" href="favicon.ico" type="image/x-icon">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="js/main.js"></script>
	<script src="js/ajax.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
	<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
	<title>Search Friends</title>
<style type="text/css">
/*div#notesBox{float:left; width:430px; border:#F0F 1px dashed; margin-right:60px; padding:10px;}
div#friendReqBox{float:left; width:430px; border:#F0F 1px dashed; padding:10px;}
div.friendrequests{height:74px; border-bottom:#CCC 1px solid; margin-bottom:8px;}
img.user_pic{float:left; width:68px; height:68px; margin-right:8px;}
div.user_info{float:left; font-size:14px;}*/
.note:nth-child(1) {
	border-top: 1px solid #ddd;
}
#results {
	margin-top:20px;
}
</style>

</head>
<body>
	<?php include_once("view_components/template_pageTop.php"); ?>
	<style type="text/css">
	.follower {
		    height: 72px;
	}
	.follower img {
		width: 50px;
		height: 50px;
	}	
	.follower .follower-name {
		position: relative;
		top:5px;
		font-size: 15px;
		font-weight: 500;
	}
</style>
        <div id="page-content-wrapper">
        	<div class="page--header">
        		<hr>
        		<h3>Search</h3>
        		<hr>
        	</div>			
            <div class="container-fluid xyz row">
            	<div class="row">
					<div class="col-xs-12 col-sm-12 col-md-12" id="profile-posts-tab">
						<div id="searchbox">
							<div class="input-group">
								<span class="input-group-addon no-background"><i class="fa fa-search"></i></span>
								<input type="text" id="uname" class="form-control" placeholder="Type your search here..." value="" maxlength="20">
								<span class="input-group-addon no-background text-semibold btn-span" onclick="searchFriends(this);">Search</span>
							</div>							
						</div>
						<div id="results">
						  <?php echo $popular_users; ?>
						</div>	
					</div>            		
            	</div>
            </div>
        </div>
    </div>
	<?php include_once("view_components/template_pageBottom.php"); ?>

	<script src="js/sidebar_menu.js"></script>
	<script type="text/javascript">
$(document).ready(function(){
	$('.sidebar-nav li').eq(5).addClass('active');
});
function emptyElement(x){
	_(x).innerHTML = "";
}
const trim = function(txt) {
	return txt.replace(/^\s+|\s+$/g,"");
}
var isSearching = false;
function searchFriends(ref){
	if(isSearching == true){
		return ;
	}
	var uname = trim(_('uname').value);
	if(uname == '' || uname == null){
		return ;
	} 
	if(isSearching == false){
		isSearching = true;
		ref.innerHTML = "Searching..";
	}
	var ajax = ajaxObj("POST", "php_parsers/search_friends.php");
	ajax.onreadystatechange = function() {
		if(ajaxReturn(ajax) == true) {
			if(ajax.responseText == "not_entered_username"){
				alert('Enter username first.');
			} else if(ajax.responseText == "user_not_found"){
				_('results').innerHTML = '<div class="text-center" style="margin-top:20px;">Nothing came up for that search, which is a little weird. Maybe check what you searched for and try again.</div>';
			} else {
				_('results').innerHTML = ajax.responseText;
			}
			ref.innerHTML = "Search";
			isSearching = false;
		}
	}
	ajax.send("action=search_friends&uname="+uname);		
}
	</script>
</body>
</html>

<?php
if(!isset($_GET['msg'])){
	header("Location: login.php");
}
$message = "";
$msg = preg_replace('#[^a-z 0-9.:_()]#i', '', $_GET['msg']);
if($msg == "activation_failure"){
	$message = '<center><div style="margin-top:60px;"><h2>Activation Error</h2> Sorry there seems to have been an issue activating your account at this time. We have already notified ourselves of this issue and we will contact you via email when we have identified the issue.</div></center>';
} else if($msg == "activation_success"){
	$message = '<center><div style="margin-top:60px;"><img src="images/activate_ok.png" width="200px"><h2>Activation Success</h2><p> Your account is now activated. <a href="login.php">Log in</a></p></div></center>';
} else {
	$message = '<center><div style="margin-top:60px;">'.$msg.'</div></center>';
}
?>
<html>
	<head>
		<style>
body {
	margin: 0px;
	font-family: sans-serif;
}
.header {
	width: 100%;
	height: 55px;
	text-align: center;
	font-size: 18px;
	color: #eee;
	background:rgb(50,50,50);
	line-height: 55px;
}
.wrapper {
	padding: 5px;
}
		</style>
	</head>
	<body>
		<div class="header">Codingflag</div>
		<div class="wrapper">
			<div><?php echo $message; ?></div>			
		</div>
	</body>
</html>


<?php
include_once("../php_includes/check_login_status.php");
include_once("../php_includes/dir_hash.php");
if($user_ok != true || $log_username == "") {
	exit();
}
?>
<?php
if (isset($_POST['action']) && $_POST['action'] == "like_status"){
	header("Content-type:application/json"); 

	// Clean the posted variables
	$statusid = preg_replace('#[^0-9]#', '', $_POST['statusid']);

	$sql = "SELECT COUNT(id) FROM status WHERE id='$statusid' LIMIT 1";
	$query = mysqli_query($db_conx, $sql);
	$row = mysqli_fetch_row($query);
	if($row[0] < 1){
		mysqli_close($db_conx);
		echo "{'status':'error',error:'status_no_exist'}";
		exit();
	}

	$row = mysqli_fetch_row( mysqli_query($db_conx, "SELECT COUNT(id) FROM likes WHERE status_id='$statusid' AND liker_id='$log_id' LIMIT 1"));
	if($row[0] < 1){
		$sql = "INSERT INTO likes(liker_id, status_id)
		        VALUES('$log_id','$statusid')";
		$query = mysqli_query($db_conx, $sql);
	}


	//Total Likes
	$row = mysqli_fetch_row(mysqli_query($db_conx, "SELECT COUNT(id) FROM likes WHERE status_id='$statusid'"));
	$total_likes = $row[0];

	$likersData = '';
	if($total_likes > 0) {
		$sql = "SELECT u.avatar,u.username FROM likes l,users u WHERE status_id='$statusid' AND l.liker_id=u.id  ORDER BY l.id DESC LIMIT 5";
		$query = mysqli_query($db_conx, $sql);
		$rows=array(); 
		while($r=mysqli_fetch_assoc($query))
		{ 
			$rows[]="user/".dir_encrypt($r["username"])."/".$r["avatar"];
		}
		$likersData = json_encode($rows);
	}	
	// Insert notifications for everybody in the conversation except this author
	// $sql = "SELECT author FROM status WHERE osid='$osid' AND author!='$log_username' GROUP BY author";
	// $query = mysqli_query($db_conx, $sql);
	// while ($row = mysqli_fetch_array($query, MYSQLI_ASSOC)) {
	// 	$participant = $row["author"];
	// 	$app = "Status Reply";
	// 	$note = $log_username.' commented here:<br /><a href="user.php?u='.$account_name.'#status_'.$osid.'">Click here to view the conversation</a>';
	// 	mysqli_query($db_conx, "INSERT INTO notifications(username, initiator, app, note, date_time)
	// 	             VALUES('$participant','$log_username','$app','$note',now())");
	// }
	mysqli_close($db_conx);
	echo '{"status":"ok","error":"none","total_likes":'.$total_likes.',"likers_avatar":['.$likersData.']}';
	exit();
}
?>
<?php
if (isset($_POST['action']) && $_POST['action'] == "unlike_status"){
	header("Content-type:application/json"); 

	// Clean the posted variables
	$statusid = preg_replace('#[^0-9]#', '', $_POST['statusid']);

	$sql = "SELECT COUNT(id) FROM status WHERE id='$statusid' LIMIT 1";
	$query = mysqli_query($db_conx, $sql);
	$row = mysqli_fetch_row($query);
	if($row[0] < 1){
		mysqli_close($db_conx);
		echo "{'status':'error',error:'status_no_exist'}";
		exit();
	}


	$sql = "DELETE FROM likes WHERE liker_id='$log_id' AND status_id='$statusid' LIMIT 1";
	$query = mysqli_query($db_conx, $sql);
	$id = mysqli_insert_id($db_conx);

	$sql = "SELECT COUNT(id) FROM likes WHERE status_id='$statusid'";
	$query = mysqli_query($db_conx, $sql);
	$row = mysqli_fetch_row($query);
	$total_likes = $row[0];

	$likersData = '';
	if($total_likes > 0) {
		$sql = "SELECT u.avatar,u.username FROM likes l,users u WHERE status_id='$statusid' AND l.liker_id=u.id  ORDER BY l.id DESC LIMIT 5";
		$query = mysqli_query($db_conx, $sql);
		$rows=array(); 
		while($r=mysqli_fetch_assoc($query))
		{ 
			$rows[]="user/".dir_encrypt($r["username"])."/".$r["avatar"];
		}
		$likersData = json_encode($rows);
	}	
	// Insert notifications for everybody in the conversation except this author
	// $sql = "SELECT author FROM status WHERE osid='$osid' AND author!='$log_username' GROUP BY author";
	// $query = mysqli_query($db_conx, $sql);
	// while ($row = mysqli_fetch_array($query, MYSQLI_ASSOC)) {
	// 	$participant = $row["author"];
	// 	$app = "Status Reply";
	// 	$note = $log_username.' commented here:<br /><a href="user.php?u='.$account_name.'#status_'.$osid.'">Click here to view the conversation</a>';
	// 	mysqli_query($db_conx, "INSERT INTO notifications(username, initiator, app, note, date_time)
	// 	             VALUES('$participant','$log_username','$app','$note',now())");
	// }
	mysqli_close($db_conx);
	echo '{"status":"ok","error":"none","total_likes":'.$total_likes.',"likers_avatar":['.$likersData.']}';
	exit();
}
?>
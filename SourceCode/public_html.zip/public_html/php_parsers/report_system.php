<?php
include_once("../php_includes/check_login_status.php");
if($user_ok != true || $log_username == "") {
	exit();
}
?>
<?php
if (isset($_POST['action']) && $_POST['action'] == "report_status"){

	// Clean the posted variables
	$statusid = preg_replace('#[^0-9]#', '', $_POST['statusid']);

	$sql = "SELECT COUNT(id) FROM status WHERE id='$statusid' LIMIT 1";
	$query = mysqli_query($db_conx, $sql);
	$row = mysqli_fetch_row($query);
	if($row[0] < 1){
		mysqli_close($db_conx);
		echo "Status not found";
		exit();
	}

	$row = mysqli_fetch_row( mysqli_query($db_conx, "SELECT COUNT(id) FROM reports WHERE status_id='$statusid' AND reporter_id='$log_id' LIMIT 1"));
	if($row[0] < 1){
		$sql = "INSERT INTO reports(reporter_id, status_id)
		        VALUES('$log_id','$statusid')";
		$query = mysqli_query($db_conx, $sql);
	}
	mysqli_close($db_conx);
	echo "reported";
	exit();
}
?>
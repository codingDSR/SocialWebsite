<?php
include_once("../php_includes/check_login_status.php");
if($user_ok != true || $log_username == "") {
	exit();
}
?>
<?php
if (isset($_POST['action']) && $_POST['action'] == "update_data"){

	function isURL($url = NULL) {
	    if($url==NULL) return false;

	    $protocol = '(http://|https://)';
	    $allowed = '([a-z0-9]([-a-z0-9]*[a-z0-9]+)?)';

	    $regex = "^". $protocol . // must include the protocol
	             '(' . $allowed . '{1,63}\.)+'. // 1 or several sub domains with a max of 63 chars
	             '[a-z]' . '{2,6}'; // followed by a TLD
	    if(eregi($regex, $url)==true) return true;
	    else return false;
	}
    $queryUpdateElements = array();
    $queryUpdate = '';
    if(isset($_POST["bioData"]) && !(empty($_POST["bioData"]))){
		$bioData = htmlentities($_POST['bioData']);
		$bioData = mysqli_real_escape_string($db_conx, $bioData);
		array_push($queryUpdateElements,"bio_data='$bioData'");
    }
    if(isset($_POST["Website"]) && !(empty($_POST["Website"]))){
		$Website = $_POST['Website'];	
		$Website = mysqli_real_escape_string($db_conx, $Website);
		array_push($queryUpdateElements,"website='$Website'");
    }
    if(isset($_POST["city"]) && !(empty($_POST["city"]))){
    	$city = preg_replace('#[^a-z0-9]#i', '', $_POST['city']);
    	$city = mysqli_real_escape_string($db_conx, $city);
    	array_push($queryUpdateElements,"city='$city'");
    }
    if(isset($_POST["gender"]) && $_POST["gender"]!='' && !(empty($_POST["gender"]))){
    	$gender = preg_replace('#[^a-z]#i', '', $_POST['gender']);
    	$gender = mysqli_real_escape_string($db_conx, $gender);
    	array_push($queryUpdateElements,"gender='$gender'");
    }
    for($i=0;$i<count($queryUpdateElements)-1;$i++){
    	$queryUpdate .= $queryUpdateElements[$i].' , ';
    }
    $queryUpdate .= $queryUpdateElements[count($queryUpdateElements)-1];
	$sql = "UPDATE users SET $queryUpdate  WHERE id='$log_id' AND username='$log_username' LIMIT 1 ";
	$query = mysqli_query($db_conx, $sql);
	if(mysqli_close($db_conx)){
		header("location: ../user.php?u=$log_username");
	} else {
		header("location: ../message.php?msg=ERROR: Unknown error occured.Please try again.");
	}
	exit();
}
?>
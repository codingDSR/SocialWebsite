<?php
include_once("../php_includes/check_login_status.php");
require_once('../php_includes/dir_hash.php');
if($user_ok != true || $log_username == "") {
	exit();
}
//sleep(5);
?>
<?php
if (isset($_POST['action']) && $_POST['action'] == "search_friends"){
	$uname = preg_replace('#[^a-z0-9.]#i', '', $_POST['uname']);
	if(empty($uname)){
		echo "not_entered_username";
		exit();
	}
	$sql = "SELECT username,avatar FROM users WHERE username LIKE '%$uname%' AND activated ='1' LIMIT 30";
	$query = mysqli_query($db_conx, $sql);
	if(mysqli_num_rows($query) < 1){
		echo "user_not_found";
		exit();
	}
	$searched_users = '';
	while ($row = mysqli_fetch_array($query, MYSQLI_ASSOC)) {
		$username = $row["username"];
		$avatar = $row["avatar"];

		$searched_users .= '<div class="follower">';
		if($avatar == null){
			$searched_users .= '<img class="friendpics"src="images/avatardefault.png" alt="'.$username.'"/>';
		} else {
			$searched_users .= '<img class="friendpics"src="user/'.dir_encrypt($username).'/'.$avatar.'" alt="'.$username.'"/>';
		}
		$searched_users .= '<div class="body">';
		$searched_users .= '<div class="follower-controls">';
		$searched_users .= '<a href="user.php?u='.$username.'" class="btn btn-sm btn-outline">View Profile</a>';
		$searched_users .= '</div>';
		$searched_users .= '<a href="user.php?u='.$username.'" class="follower-name">'.$username.'</a><br></div></div>';

	}
    echo $searched_users;
    exit();
}
?>
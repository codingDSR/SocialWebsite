<?php
include_once("../php_includes/check_login_status.php");
include_once("../php_includes/dir_hash.php");
if($user_ok != true || $log_username == "") {
	//exit();
}
?>
<?php
if (isset($_POST['action']) && $_POST['action'] == "load_status_comments"){
	// Clean the posted variables
	$u = preg_replace('#[^a-z0-9.]#i', '', $_POST['u']);
	$user_id = preg_replace('#[^0-9]#', '', $_POST['uid']);
	$statusid = preg_replace('#[^0-9]#', '', $_POST['statusid']);
	$loadedComments = preg_replace('#[^0-9]#', '', $_POST['loadedComments']);

	$res = mysqli_query($db_conx,"SELECT account_id FROM status where id='$statusid' LIMIT 1");
	if(mysqli_num_rows($res) > 0){
		while($row = mysqli_fetch_array($res)){
			$account_name = $row["account_id"];
		}
	} else {
		$account_name = $u;
	}
	//$account_name = $u;
	$range = 5;
	include_once("../view_components/template_logged_user_avatar.php");

	$statuslist = '';
	$oneStatusBlock = ''; 
	$avatar = '';
	$isFriend = false;
	$ownerBlockViewer = false;
	$viewerBlockOwner = false;

	if($u != $log_username && $user_ok == true){
		$friend_check = "SELECT id FROM friends WHERE user1_id='$log_id' AND user2_id='$user_id' AND accepted='1' OR user1_id='$user_id' AND user2_id='$log_id' AND accepted='1' LIMIT 1";
		if(mysqli_num_rows(mysqli_query($db_conx, $friend_check)) > 0){
	        $isFriend = true;
	    }
	}

	$status_replies = "";
	$query_replies = mysqli_query($db_conx, 
	   "SELECT s.*,u.username,u.avatar  
		FROM status s,users u 
		WHERE 
			osid='$statusid' 
			AND 
			type='b'
			AND
			s.author_id=u.id 
		ORDER BY postdate DESC
		LIMIT $loadedComments,$range
	");
	$query_total_replies = mysqli_query($db_conx, 
		   "SELECT COUNT(s.id)
			FROM status s
			WHERE 
				osid='$statusid' 
				AND 
				type='b'
	");
	$reply_total_num_rows = mysqli_fetch_row($query_total_replies);	
	$reply_total_nums = $reply_total_num_rows[0];
	$replynumrows = mysqli_num_rows($query_replies);
    if($replynumrows > 0){
        while ($row2 = mysqli_fetch_array($query_replies, MYSQLI_ASSOC)) {
			$statusreplyid = $row2["id"];
			$replyauthor = $row2["author_id"];
			$replay_author_name = $row2["username"];
			$replay_author_avatar = $row2["avatar"];
			$replydata = $row2["data"];
			$replydata = nl2br($replydata);
			//$replypostdate = $row2["postdate"];
			$replypostdate = date('M d, Y', strtotime($row2["postdate"]));
			$replydata = str_replace("&amp;","&",$replydata);
			$replydata = stripslashes($replydata);
			$replyDeleteButton = '';
			if($replyauthor == $log_id || $account_name == $log_id ){
				$replyDeleteButton = 
					'<span id="srdb_'.$statusreplyid.'">
						<a href="#" onclick="return false;" onmousedown="deleteReply(\''.$statusreplyid.'\',\'reply_'.$statusreplyid.'\');" title="DELETE THIS COMMENT">Delete</a>
					</span>';
			}
			$reply_author_profile_pic = '';
		    $reply_author_profile_pic = '<img src="user/'.dir_encrypt($replay_author_name).'/'.$replay_author_avatar.'" alt="'.$replay_author_name.'">';
		    if($replay_author_avatar == NULL){
		        $reply_author_profile_pic = '<img src="images/avatardefault.jpg" alt="'.$replay_author_name.'">';
		    }   
			$status_replies .= 
				'<div id="reply_'.$statusreplyid.'" class="reply_boxes row">
					<div class="col-xs-2 col-sm-2 col-md-1">'.
						$reply_author_profile_pic.'
					</div>
					<div class="col-xs-10 col-sm-10 col-md-11">	
						<h5><a href="user.php?u='.$replay_author_name.'">'.$replay_author_name.'</a></h5>'.
						'<p class="replaydata">'.$replydata.'<p class="reply_meta">'.
						'<span>'.$replypostdate.' &nbsp;'.
						$replyDeleteButton.
						'</span>'.						
					'</div>
				</div>';
        }
        if(($loadedComments+$replynumrows) == $reply_total_nums){
        	echo $status_replies;
        	exit();
        }
    	if($reply_total_nums > $replynumrows){
    		$status_replies .= '<div class="load-more-comments"><a  onclick="loadMoreComments(event,this,2);" data-loaded="'.($loadedComments+$replynumrows).'" data-trep="'.$reply_total_nums.'" data-std="'.$statusid.'">view more</a></div>';
    	}        
    	echo $status_replies;
  	} else {
  		echo "no_more_comments";
  	}
}
?>
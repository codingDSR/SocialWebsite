<?php
include_once("../php_includes/check_login_status.php");
if($user_ok != true || $log_username == "") {
	exit();
}
?>
<?php
if (isset($_POST['action']) && $_POST['action'] == "mark_read_note"){
	// Clean the posted variables
	$noteid = preg_replace('#[^0-9]#', '', $_POST['noteid']);
	$sql = "UPDATE notifications SET did_read='1' WHERE id='$noteid' LIMIT 1";
	if(mysqli_query($db_conx, $sql)){
		mysqli_close($db_conx);
		echo "mark_ok";
		exit();
	} else {
		mysqli_close($db_conx);
		echo "unknown_error";
	}
}
?>